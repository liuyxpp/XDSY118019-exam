import json
from pathlib import Path
import matplotlib.pyplot as plt

summary = json.loads(Path('experiments/summary.json').read_text(encoding='utf8'))
Path('figures').mkdir(exist_ok=True)
histories = {}
for run in summary['runs']:
    result = json.loads(Path(f"experiments/{run['name']}.json").read_text(encoding='utf8'))
    histories[run['name']] = result['history']
print('历史字段:', next(iter(histories.values())).keys())

for name, history in histories.items():
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.plot(history['epoch'], history['train_loss'], label='Training loss')
    ax.plot(history['epoch'], history['val_loss'], label='Validation loss')
    ax.set_title(f'{name}: training and validation loss')
    ax.set_xlabel('Epoch')
    ax.set_ylabel('MSE (standardized log10 target)')
    ax.set_yscale('log')
    ax.legend()
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(Path('figures') / f'{name}_loss.png', dpi=160)
    plt.close(fig)