# MLP 实验报告

## 数据检查与验证

原始数据共有 813 条记录。运行 `clean_records` 后保留 800 条，清洗日志包含 13 条记录：`block_1_ends` 1 次、`block_1_length` 1 次、`block_1_segment` 1 次、`block_2_segment` 1 次、`block_4_length` 1 次、`disconnected_graph` 3 次、`duplicate_or_equivalent_structure` 2 次、`length_sum_not_one` 2 次、`missing_or_invalid_chiN_star` 2 次；处理动作是拒绝 11 条、等价重复结构保留第一条 2 条。长度非法或总和不为 1 会使长度比例特征失去定义，因此拒绝而不猜测修补；缺失或非正的 `chiN_star` 不能进行 `log10` 变换，也不能作为监督标签，因此拒绝。连接端点非法或结构不连通不符合一个有效聚合物结构的定义，也予以拒绝；等价结构仅保留第一条可避免重复结构跨越训练和验证集合。所有清洗规则均与模型预测误差无关。

使用种子 20261105，以 `structure_group` 生成的结构键进行 `GroupShuffleSplit`，验证比例为 0.2；最终训练集 640 条、验证集 160 条，结构组交集为 0。特征与目标标准化参数只用训练集拟合，再原样应用于验证集，因此验证信息没有进入预处理。详细样本 ID、清洗日志和划分信息见 `experiments/cleaning_log.json` 与 `experiments/summary.json`。

## 输入、网络与损失

四个默认特征是嵌段数、A 类嵌段总长度比例、最短嵌段长度和最长嵌段长度：它们分别描述结构规模、组成以及长度范围。最终模型在此基础上扩展为 33 个固定长度描述符，包括节点数与环数、较小组分比例及组成不平衡、长度标准差/平方和/熵与排序后的前五个长度、叶节点和分支节点数、节点度统计及前六个排序度数、同类/异类嵌段在节点处相接的次数与长度乘积，以及平均节点距离和直径。描述符不使用 `sample_id`、`k_star` 或标签派生量，并通过排序、较小组分统计和同类/异类关系保持对节点重命名、嵌段顺序及全局 A/B 互换不敏感。

单个样本输入形状为 `(33,)`，批量输入为 `(N, 33)`；基线网络为 33→64→64→1，对照网络为 33→128→128→1，输出形状均为 `(N, 1)`。两个隐藏层使用 ReLU，即把负的预激活置为 0 并保留正值，为网络加入非线性；Adam 根据梯度的一阶和二阶动量自适应更新参数。

目标先变换为 `log10(chiN_star)`，再用训练集目标均值和标准差进行标准化，这可压缩目标尺度并使优化更稳定。训练损失是标准化后 log10 目标的均方误差 MSE，它对较大的 log 空间误差给予平方惩罚；MAPE 则是在原始 `chiN_star` 尺度上计算相对误差百分比，两者定义、尺度和用途不同。训练使用 MSE，并按验证 MSE 选择 checkpoint；原尺度 MAE、MAPE 和 log_MAE 仅用于解释验证表现。

## 基线与一次对照

两组实验共用相同的 33 个特征、训练/验证划分、种子 20261105、学习率 0.003、Adam、1000 个 epoch 和目标处理，仅将隐藏层宽度从 64 改为 128，因此比较是公平的。框架记录全部 epoch，保存各组验证 loss 最低的 checkpoint，并在两组 checkpoint 中按最低验证 loss 选择最终模型。

| 实验 | width | lr | epochs | 最佳epoch | 最佳验证loss | 验证MAE | 验证MAPE（%） | 验证log_MAE |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| baseline_structural_width64 | 64 | 0.003 | 1000 | 971 | 0.008267 | 3.870686 | 4.826169 | 0.020657 |
| comparison_structural_width128 | 128 | 0.003 | 1000 | 901 | 0.007400 | 3.449188 | 4.468345 | 0.019212 |

最终选择 `comparison_structural_width128` 的第 901 轮 checkpoint，因为它的验证 MSE 低于宽度 64 的模型；它同时在验证 MAE、MAPE 和 log_MAE 上更好，因此不同验证指标给出了一致排序。模型没有在全部数据上重训，以保留独立验证证据。

## 自己绘制的 loss 曲线与解释

![宽度64训练与验证loss](figures/baseline_structural_width64_loss.png)

![宽度128训练与验证loss](figures/comparison_structural_width128_loss.png)

两组训练和验证 loss 都在前期快速下降，随后缓慢改善，说明优化已经收敛；纵轴采用对数尺度以显示后期差异。宽度 64 在第 971 轮取得最低验证 loss 0.008267，最后一轮回升到 0.008668。宽度 128 在第 901 轮取得更低的验证 loss 0.007400，最后一轮为 0.007460，因此选取 checkpoint 优于直接使用最后一轮。两组后期训练 loss 均明显低于验证 loss，存在一定过拟合，但验证曲线没有持续发散。增加宽度提高了拟合结构描述符与目标非线性关系的能力，并将验证 MAPE 从 4.826% 降到 4.468%，因此选择宽度 128。局限是数据量仍只有 800 条，结构特征是人工汇总量，单次 80/20 划分也可能带来估计波动，隐藏测试表现不能由公开验证结果保证。

绘图源码见 `experiments/plot_loss.py`，真实逐 epoch 历史见 `experiments/baseline_structural_width64.json` 和 `experiments/comparison_structural_width128.json`。

## 最佳提交与复现

- 环境：Python 3.12；依赖见 `requirements.txt`。
- 训练：`python train.py --seed 20261105`。
- 绘图：`python experiments/plot_loss.py`，或按 Notebook 顺序运行任务 4 单元。
- CPU 接口自检：`python selfcheck.py --device cpu`。
- 最终权重：`artifacts/model.pt`，对应 `comparison_structural_width128` 第 901 轮。
- 最终模型未在全部数据上重训；保存的是独立验证集 loss 最低的 checkpoint。
- 打包：`python package_submission.py --output submission.zip`。
- 最终增强版已通过网页 CPU 正式评测：MAPE 4.517%、MAE 3.740、RMSE 9.519、R² 0.9934、log_MAE 0.01980，模型跑分 40/40。
- 所选网页 task_id：`ca3e68d7c0364dbbb0e2aadd190f3d9d`；job_id（成绩编号）：`33f5fad54b204cce9a61032c245740f5`；设备：CPU。
- GitHub 私有仓库：`https://github.com/jiangqiqi7/XDSY118019_assignment`。网页满分模型对应的固定源码、权重与预处理提交为 `93f8dcb0e6d93fe3edfef852314081fa80526af8`；补充本行报告后的最终提交另在课程平台登记。最终推理代码、特征、权重和预处理参数与上述网页任务一致。
