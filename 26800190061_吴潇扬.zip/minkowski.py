"""Minkowski 距离：在原始框架上补充参数校验与使用示例。

代码按“先检查输入，再计算”的顺序组织，便于初学者阅读：
1. 用文件自带的 _validate_vector / _validate_weights 检查 u、v、w；
2. 新增 _validate_p 检查 p；
3. 加权后用 scipy.linalg.norm 一次算出 p-范数。
"""

import math

import numpy as np
from scipy.linalg import norm


def _validate_vector(u, dtype=None):
    """把输入转成 1 维 numpy 数组；不是 1 维就报错。"""
    u = np.asarray(u, dtype=dtype, order='c')
    if u.ndim == 1:
        return u
    raise ValueError("Input vector should be 1-D.")


def _validate_weights(w, dtype=np.float64):
    """权重必须是 1 维数组，且不能为负数。"""
    w = _validate_vector(w, dtype=dtype)
    if np.any(w < 0):
        raise ValueError("Input weights should be all non-negative")
    return w


def _validate_p(p):
    """检查 p：必须是正的实数标量，允许 np.inf。

    这里单独写一个函数，而不是塞进 minkowski 里，是为了让 p 的规则集中、
    容易测试。布尔值 True/False 要单独排除，否则 float(True) 会变成 1。
    """
    if isinstance(p, bool) or not np.isscalar(p):
        raise TypeError("p must be a real scalar")
    p = float(p)
    if math.isnan(p) or p <= 0:
        raise ValueError("p must be positive (p > 0) or np.inf")
    return p


def minkowski(u, v, p=2, w=None):
    """
    Compute the Minkowski distance between two 1-D arrays.

    The Minkowski distance between 1-D arrays `u` and `v`,
    is defined as

    .. math::

       {\\|u-v\\|}_p = (\\sum{|u_i - v_i|^p})^{1/p}.


       \\left(\\sum{w_i(|(u_i - v_i)|^p)}\\right)^{1/p}.

    Parameters
    ----------
    u : (N,) array_like
        Input array.
    v : (N,) array_like
        Input array.
    p : scalar
        The order of the norm of the difference :math:`{\\|u-v\\|}_p`. Note
        that for :math:`0 < p < 1`, the triangle inequality only holds with
        an additional multiplicative factor, i.e. it is only a quasi-metric.
    w : (N,) array_like, optional
        The weights for each value in `u` and `v`. Default is None,
        which gives each value a weight of 1.0

    Returns
    -------
    minkowski : double
        The Minkowski distance between vectors `u` and `v`.

    Raises
    ------
    TypeError
        If `p` is not a real scalar.
    ValueError
        If `u` or `v` is not 1-D, if their shapes differ, if `w` is not 1-D,
        has negative entries or a length different from `u`, or if `p <= 0`.

    Examples
    --------
    >>> distance.minkowski([1, 0, 0], [0, 1, 0], 1)
    2.0
    >>> distance.minkowski([1, 0, 0], [0, 1, 0], 2)
    1.4142135623730951
    >>> distance.minkowski([1, 0, 0], [0, 1, 0], np.inf)
    1.0
    >>> distance.minkowski([1, 2, 3], [3, 2, 1], 2, w=[0.1, 0.7, 0.2])
    1.0954451150103321
    >>> distance.minkowski([0, 1, 1, 0, 0, 1], [1, 0, 0, 1, 1, 0], 0.5)
    36.0
    >>> distance.minkowski([1, 2], [4, 6], 3)
    4.497941445275415
    >>> distance.minkowski([0, 0], [3, 4], 2)
    5.0
    """
    # 第 1 步：检查 u、v 都是一维，并且长度相同。
    u = _validate_vector(u)
    v = _validate_vector(v)
    if u.shape != v.shape:
        raise ValueError("Input vectors must have the same length.")

    # 第 2 步：检查 p。
    p = _validate_p(p)

    # 第 3 步：如果有权重，检查权重并把权重开 p 次方后乘到差向量上。
    # 这样 ||root_w * (u - v)||_p 正好等于加权 Minkowski 距离。
    if w is not None:
        w = _validate_weights(w)
        if w.shape != u.shape:
            raise ValueError("Weights must have the same length as u and v.")
        if p == 1:
            root_w = w
        elif p == 2:
            root_w = np.sqrt(w)          # 开平方更快、更精确
        elif p == np.inf:
            root_w = (w != 0)            # 权重为 0 的坐标不参与最大值
        else:
            root_w = np.power(w, 1 / p)
        diff = root_w * (u - v)
    else:
        diff = u - v

    # 第 4 步：scipy 的 norm 直接计算 p-范数。
    return float(norm(diff, ord=p))


if __name__ == '__main__':
    pass
