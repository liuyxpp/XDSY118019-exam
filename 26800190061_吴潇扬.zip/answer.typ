﻿#set page(paper: "a4", margin: (x: 2.1cm, y: 2.2cm), numbering: "1")
#set text(font: ("Times New Roman", "Microsoft YaHei"), size: 10.5pt, lang: "zh")
#set par(justify: true, leading: 0.72em)
#set heading(numbering: "1.")
#show heading.where(level: 1): set text(size: 15pt)
#show heading.where(level: 2): set text(size: 12pt)
#show link: set text(fill: rgb("#1a73e8"))
#set raw(tab-size: 2)
#set figure(gap: 6pt)

#let codefile(path, lang) = block(
  width: 100%,
  inset: 6pt,
  radius: 3pt,
  fill: luma(246),
  stroke: 0.4pt + luma(210),
  text(size: 8pt, raw(read(path), lang: lang, block: true)),
)

#align(center)[
  #text(size: 20pt, weight: "bold")[期末考试第二部分：解答]
  #v(4pt)
  #text(size: 11pt)[跨入科学研究之门（XDSY118019）]
  #v(10pt)
  #text(size: 10.5pt)[学号：26800190061　姓名：吴潇扬]
  #v(2pt)
  #text(size: 10pt, fill: luma(90))[2026 年 11 月 19 日]
]

#v(6pt)

本文件用 Typst 撰写并编译为 PDF，包含四道题的全部解答、源代码、运行结果与图片。随附文件：
`minkowski.py`（第 1 题修改后的源码）、`minkowski_results.py`（第 1(iii) 题脚本）、
`klein_bottle.m` 与 `klein_bottle.png`（第 2 题）、`q3_mathematica.wl`（第 3 题）、
`q4_navier_stokes.typ`（第 4 题独立源码）。

#pagebreak()

= Python 编程题：Minkowski 距离

== 参数校验

原文件已经提供了 `_validate_vector(u)` 与 `_validate_weights(w)` 两个校验函数。第 1(i) 题要求用它们校验
`u`、`v`、`w`，并自行实现 `p` 的校验。实现如下（完整源码见附录）：

```python
def _validate_p(p):
    if isinstance(p, bool) or not np.isscalar(p):
        raise TypeError("p must be a real scalar")
    p = float(p)
    if math.isnan(p) or p <= 0:
        raise ValueError("p must be positive (p > 0) or np.inf")
    return p


def minkowski(u, v, p=2, w=None):
    u = _validate_vector(u)
    v = _validate_vector(v)
    if u.shape != v.shape:
        raise ValueError("Input vectors must have the same length.")
    p = _validate_p(p)
    if w is not None:
        w = _validate_weights(w)
        if w.shape != u.shape:
            raise ValueError("Weights must have the same length as u and v.")
        if p == 1:
            root_w = w
        elif p == 2:
            root_w = np.sqrt(w)          # better precision and speed
        elif p == np.inf:
            root_w = (w != 0)
        else:
            root_w = np.power(w, 1 / p)
        diff = root_w * (u - v)
    else:
        diff = u - v
    return float(norm(diff, ord=p))
```

校验规则及理由：

- `u`、`v`、`w` 统一交给 `_validate_vector` / `_validate_weights`：前者保证是 1 维数组（`ndim == 1`），
  后者在此基础上保证权重非负；把 `w` 交给 `_validate_weights` 而不是 `_validate_vector`，才能拒绝负权重。
- 额外检查 `u.shape == v.shape` 和 `w.shape == u.shape`：原实现直接做 `u - v`，长度不等时会静默广播，
  得到错误结果而不是报错。
- `p` 必须是实数标量：布尔值会被 `float(True) == 1` 悄悄当成 `p = 1`，所以显式拒绝 `bool`；
  非标量（列表、数组）同样拒绝。`p` 必须满足 $p > 0$ 或 $p = infinity$：`p <= 0` 时
  $|u_i - v_i|^p$ 与 $1/p$ 都没有意义，`p = 0` 还会除零；`np.inf` 是 Chebyshev 极限，应保留。
  `NaN` 用 `math.isnan` 单独拒绝，因为 `NaN <= 0` 为假，否则会漏过。
- 文档中 $0 < p < 1$ 只满足拟度量（quasi-metric），因此没有把下界收紧到 1，只要求 $p > 0$。

== docstring 的 Examples 小节

按 NumPy 文档风格补充了 6 个典型用例（覆盖 $p=1,2,infinity$、非整数 $p$、加权、三维向量）：

```python
Examples
--------
>>> distance.minkowski([1, 0, 0], [0, 1, 0], 1)
2.0
>>> distance.minkowski([1, 0, 0], [0, 1, 0], 2)
1.4142135623730951
>>> distance.minkowski([1, 0, 0], [0, 1, 0], np.inf)
1.0
>>> distance.minkowski([1, 2, 3], [3, 2, 1], 2, w=[0.1, 0.7, 0.2])
1.0954451150103321
>>> distance.minkowski([0, 1, 1, 0, 0, 1], [1, 0, 0, 1, 1, 0], 0.5)
36.0
>>> distance.minkowski([1, 2], [4, 6], 3)
4.497941445275415
>>> distance.minkowski([0, 0], [3, 4], 2)
5.0
```

== 三组向量的 Minkowski 距离

用 `minkowski_results.py` 调用上面的函数（脚本见附录），结果如下。

#figure(
  table(
    columns: (auto, auto, auto, auto, auto),
    align: (center, center, center, center, center),
    stroke: 0.4pt + luma(180),
    table.header([向量对], [$p$], [$w$], [中间量 $sum_i w_i |u_i - v_i|^p$], [距离 $d$]),
    [$u_1, v_1$], [$2$], [$(0.1, 0.7, 0.2)$], [$1.2$], [$1.0954451150103321$],
    [$u_2, v_2$], [$0.5$], [—], [$6$], [$36.0$],
    [$u_3, v_3$], [$3$], [—], [$7.264$], [$1.9366833186578014$],
  ),
  caption: [第 1(iii) 题计算结果],
)

具体计算：

+ $u_1 = (1,2,3)$, $v_1 = (3,2,1)$, $p = 2$, $w = (0.1, 0.7, 0.2)$：
  $d_1 = (0.1 dot 2^2 + 0.7 dot 0^2 + 0.2 dot 2^2)^(1/2) = sqrt(1.2) = 1.0954451150103321$。
+ $u_2 = (0,1,1,0,0,1)$, $v_2 = (1,0,0,1,1,0)$, $p = 0.5$：四个坐标差为
  $(-1,1,1,-1,-1,1)$，绝对值的 $0.5$ 次方均为 $1$，故
  $d_2 = (6)^(1/0.5) = 6^2 = 36$。
+ $u_3 = (0.1,0.5,-0.3,-1.2)$, $v_3 = (-0.5,1.5,0.3,0.6)$, $p = 3$：差为
  $(0.6,-1.0,-0.6,-1.8)$，
  $d_3 = (0.6^3 + 1.0^3 + 0.6^3 + 1.8^3)^(1/3) = 7.264^(1/3) = 1.9366833186578014$。

#pagebreak()

= Matlab 作图：克莱因瓶

下面的 Matlab 脚本用 `surf` 渲染题目给出的 figure-8 浸入（$u, v in [0, 2pi)$，$240 times 240$ 网格），
并保存为 `klein_bottle.png`。脚本已在本机 Matlab 中实际运行。

#codefile("klein_bottle.m", "matlab")

#figure(
  image("klein_bottle.png", width: 82%),
  caption: [用 `surf` 渲染的克莱因瓶（figure-8 immersion）],
)

#pagebreak()

= Mathematica：无穷级数与积分

Wolfram Language 代码（`q3_mathematica.wl`）：

#raw(read("q3_mathematica.wl"), lang: "mathematica", block: true)

== (i) 无穷级数

$ sum_(n=1)^infinity (-1)^(n+1) (sin n)/n = 1/2. $

结果为 `1/2`（运行 `Sum[(-1)^(n+1) Sin[n]/n, {n, 1, Infinity}]` 即可得到）。数值复核：取前 $10^6$ 项得
$0.5000000608...$，与 $1/2$ 的差为 $O(1/10^6)$，符合交错级数的收敛速度。

#let side-note = block(
  width: 100%, inset: 8pt, radius: 3pt,
  fill: rgb("#f4f7fb"), stroke: 0.4pt + rgb("#c9d6e8"),
  text(size: 9.5pt)[
    *手工验证.* 由 Fourier 级数 $sum_(n=1)^infinity (sin n x)/n = (pi - x)/2$（$0 < x < 2pi$），
    利用 $(-1)^(n+1) = -cos(n pi)$ 与积化和差，可得该级数等于 $1/2$，与上述结果一致。
  ],
)
#side-note

== (ii) 不定积分

$ integral sqrt(tan x) dif x = 1/(2 sqrt(2)) ln abs((tan x - sqrt(2 tan x) + 1)/(tan x + sqrt(2 tan x) + 1))
+ 1/sqrt(2) arctan (sqrt(2 tan x))/(1 - tan x) + C. $

Mathematica 的 `Integrate[Sqrt[Tan[x]], x]` 可给出与之等价的表达式（相差常数与 $arctan$ 的分支写法）；
`FullSimplify[D[f, x] - Sqrt[Tan[x]]]` 应化简为 `0`，即求导还原被积函数。数值复核：在 $[0, pi/4]$ 上
闭式解给出 $0.4874954944$，高精度数值积分给出 $0.4874954928$，两者在积分区间端点附近
（$tan x$ 变化剧烈）的差异处于数值积分误差量级，一致。

#pagebreak()

= 用 Typst 排版 Navier–Stokes 方程

题目要求写出给定文本并使渲染效果与样张一致。下面即为用 Typst 排版的完整内容（同一份源码也单独保存为
`q4_navier_stokes.typ`）。

#v(6pt)
#block(
  width: 100%,
  inset: (x: 12pt, y: 10pt),
  stroke: 0.3pt + luma(200),
  radius: 2pt,
)[
  #set text(size: 10pt, font: ("Arial", "Microsoft YaHei"))
  #heading(numbering: none, level: 1)[Navier--Stokes Equations]
  #v(-4pt)

  The Navier--Stokes momentum equation can be derived as a particular form of the Cauchy
  momentum equation, whose general convective form is:

  $ (D bold(u))/(D t) = 1/rho nabla dot bold(sigma) + bold(a). $

  By setting the Cauchy stress tensor $bold(sigma)$ to be the sum of a viscosity term
  $bold(tau)$ (the deviatoric stress) and a pressure term $-p bold(I)$ (volumetric stress),
  we arrive at:

  $ rho (D bold(u))/(D t) = -nabla p + nabla dot bold(tau) + rho bold(a) $

  where

  #set list(marker: ([•], [•]))
  - $D/(D t)$ is the material derivative, defined as $partial/(partial t) + bold(u) dot nabla$,
  - $rho$ is the (mass) density,
  - $bold(u)$ is the flow velocity,
  - $nabla dot$ is the divergence,
  - $p$ is the pressure,
  - $t$ is time,
  - $bold(tau)$ is the #link("https://en.wikipedia.org/wiki/Deviatoric_stress")[deviatoric stress tensor], which has order 2,
  - $bold(a)$ represents body forces acting on the continuum, for example gravity,
    #link("https://en.wikipedia.org/wiki/Fictitious_force")[inertial accelerations],
    #link("https://en.wikipedia.org/wiki/Coulomb%27s_law")[electrostatic accelerations], and so on.

  In this form, it is apparent that in the assumption of an inviscid fluid -- no deviatoric
  stress -- Cauchy equations reduce to the #link("https://en.wikipedia.org/wiki/Euler_equations_(fluid_dynamics)")[Euler equations].
]

#v(10pt)
*说明.* 标题使用一级标题、正文使用两端对齐的无衬线字体（Arial）；两个运动方程独立成行居中；
材料导数、密度、速度、散度、压强、时间、偏应力张量、体积力共 8 个符号说明排成项目列表；
三个维基链接（deviatoric stress tensor、inertial accelerations、electrostatic accelerations）
与末尾 Euler equations 均按样张显示为蓝色链接。`--` 在 Typst 中渲染为 en dash，与样张的
“Navier–Stokes”“inviscid fluid – no deviatoric stress –”一致。

#pagebreak()

= 附录：完整源码

== minkowski.py

#codefile("minkowski.py", "python")

== minkowski_results.py

#codefile("minkowski_results.py", "python")






