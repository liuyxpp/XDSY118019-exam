"""Q1(iii): Minkowski distances for the three vector pairs in the exam."""
import json
from pathlib import Path

import numpy as np

from minkowski import minkowski

CASES = [
    ("(u1, v1)", [1, 2, 3], [3, 2, 1], 2, [0.1, 0.7, 0.2]),
    ("(u2, v2)", [0, 1, 1, 0, 0, 1], [1, 0, 0, 1, 1, 0], 0.5, None),
    ("(u3, v3)", [0.1, 0.5, -0.3, -1.2], [-0.5, 1.5, 0.3, 0.6], 3, None),
]

rows = []
for label, u, v, p, w in CASES:
    d = minkowski(u, v, p, w)
    rows.append({"pair": label, "u": u, "v": v, "p": p, "w": w,
                 "distance": d, "distance_repr": repr(d)})
    print(f"{label}: p={p}, w={w} -> {d!r}")

Path("minkowski_results.json").write_text(
    json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf8")
