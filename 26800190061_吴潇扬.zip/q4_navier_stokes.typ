﻿// 第 4 题：Navier–Stokes Equations（独立可编译源码）
#set page(paper: "a4", margin: 2.5cm)
#set text(font: ("Arial", "Microsoft YaHei"), size: 11pt, lang: "en")
#set par(justify: true)
#show link: set text(fill: rgb("#1a73e8"))
#show heading.where(level: 1): set text(size: 26pt, weight: "bold")

#heading(numbering: none)[Navier--Stokes Equations]

The Navier--Stokes momentum equation can be derived as a particular form of the Cauchy
momentum equation, whose general convective form is:

$ (D bold(u))/(D t) = 1/rho nabla dot bold(sigma) + bold(a). $

By setting the Cauchy stress tensor $bold(sigma)$ to be the sum of a viscosity term
$bold(tau)$ (the deviatoric stress) and a pressure term $-p bold(I)$ (volumetric stress),
we arrive at:

$ rho (D bold(u))/(D t) = -nabla p + nabla dot bold(tau) + rho bold(a) $

where

- $D/(D t)$ is the material derivative, defined as $partial/(partial t) + bold(u) dot nabla$,
- $rho$ is the (mass) density,
- $bold(u)$ is the flow velocity,
- $nabla dot$ is the divergence,
- $p$ is the pressure,
- $t$ is time,
- $bold(tau)$ is the #link("https://en.wikipedia.org/wiki/Deviatoric_stress")[deviatoric stress tensor], which has order 2,
- $bold(a)$ represents body forces acting on the continuum, for example gravity,
  #link("https://en.wikipedia.org/wiki/Fictitious_force")[inertial accelerations],
  #link("https://en.wikipedia.org/wiki/Coulomb%27s_law")[electrostatic accelerations], and so on.

In this form, it is apparent that in the assumption of an inviscid fluid -- no deviatoric
stress -- Cauchy equations reduce to the #link("https://en.wikipedia.org/wiki/Euler_equations_(fluid_dynamics)")[Euler equations].

