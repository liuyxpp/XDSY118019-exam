﻿XDSY118019 期末考试第二部分 提交材料
学号：26800190061  姓名：吴潇扬

answer.pdf             解答与排版结果（10 页）
answer.typ             答案的 Typst 源文件（含全部代码与结果）
minkowski.py           第 1 题修改后的源码（参数校验 + 6 个 Examples）
minkowski_results.py   第 1(iii) 题计算脚本
minkowski_results.json 第 1(iii) 题计算结果
klein_bottle.m         第 2 题 Matlab surf 脚本
klein_bottle.png       第 2 题渲染结果
q3_mathematica.wl      第 3 题 Wolfram Language 代码
q4_navier_stokes.typ   第 4 题独立 Typst 源码
q4_navier_stokes.pdf   第 4 题单独渲染结果
