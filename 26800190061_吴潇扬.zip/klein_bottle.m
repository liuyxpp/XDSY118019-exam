﻿% Klein bottle (figure-8 immersion) rendered with surf.
% XDSY118019 final exam, part 2, question 2.
clear; clc; close all;

n = 240;
u = linspace(0, 2*pi, n);
v = linspace(0, 2*pi, n);
[U, V] = meshgrid(u, v);

cu = cos(U); su = sin(U); cv = cos(V); sv = sin(V);

X = -2/15 * cu .* (3*cv - 30*su + 90*cu.^4.*su - 60*cu.^6.*su ...
                   + 5*cu.*cv.*su);
Y = -1/15 * su .* (3*cv - 3*cu.^2.*cv - 48*cu.^4.*cv + 48*cu.^6.*cv ...
                   - 60*su + 5*cu.*cv.*su - 5*cu.^3.*cv.*su ...
                   - 80*cu.^5.*cv.*su + 80*cu.^7.*cv.*su);
Z = 2/15 * (3 + 5*cu.*su) .* sv;

fig = figure('Color', 'w', 'Position', [100 100 900 760]);
surf(X, Y, Z, 'EdgeColor', 'none', 'FaceColor', 'interp');
colormap(turbo);
camlight('headlight');
lighting gouraud;
material([0.75 0.55 0.25 12 0.7]);
axis equal;
axis off;
view(35, 28);
title('Klein bottle (figure-8 immersion)', 'FontSize', 14, 'FontWeight', 'normal');
set(gca, 'FontSize', 12);

exportgraphics(fig, 'klein_bottle.png', 'Resolution', 220);
fprintf('saved klein_bottle.png\n');

