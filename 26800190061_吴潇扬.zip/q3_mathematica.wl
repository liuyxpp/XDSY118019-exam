(* XDSY118019 final exam, part 2, question 3.
   Evaluate with:  wolframscript -file q3_mathematica.wl               *)

Print["== (i) infinite series =="];
s = Sum[(-1)^(n + 1) Sin[n]/n, {n, 1, Infinity}];
Print["Sum[(-1)^(n+1) Sin[n]/n, {n,1,Infinity}] = ", s];
Print["N[..., 30] = ", N[s, 30]];
Print["Numeric check (10^6 terms) = ",
      N[Sum[(-1)^(n + 1) Sin[n]/n, {n, 1, 1000000}], 20]];

Print["== (ii) indefinite integral =="];
f = Integrate[Sqrt[Tan[x]], x];
Print["Integrate[Sqrt[Tan[x]], x] = ", f];
Print["Simplified = ", FullSimplify[f]];
Print["Derivative check (should simplify to 0): ",
      FullSimplify[D[f, x] - Sqrt[Tan[x]]]];

(* Definite check on [0, Pi/4], compared with high-precision numeric *)
def = Integrate[Sqrt[Tan[x]], {x, 0, Pi/4}];
Print["Integrate[Sqrt[Tan[x]], {x,0,Pi/4}] = ", def, " = ", N[def, 25]];
Print["NIntegrate check = ", NIntegrate[Sqrt[Tan[x]], {x, 0, Pi/4}, 20]];
