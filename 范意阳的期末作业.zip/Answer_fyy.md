# Problem1:

Code:

```python
from format_number import *

test = [1.234, 0.567, 234, -1.234, -0.567, -234]
result = []
for i in range(5):
    result.append([])

# 测试用例1 - 无参数
for num in test:
    num2str = format_number(num)
    result[0].append((num, num2str))

# 测试用例2 - 保留2位小数
for num in test:
    num2str = format_number(num, decimals=2)
    result[1].append((num, num2str))

# 测试用例3 - 保留-2位小数
for num in test:
    num2str = format_number(num, decimals=-2)
    result[2].append((num, num2str))

# 测试用例4 - last_digit=[3, 4]
for num in test:
    num2str = format_number(num, last_digit=[3, 4])
    result[3].append((num, num2str))

# 测试用例5 - 保留2位小数，last_digit=[3, 4]
for num in test:
    num2str = format_number(num, decimals=-2, last_digit=[3, 4])
    result[4].append((num, num2str))

print(result)
```

Run example:

> [[(1.234, '1'), (0.567, '1'), (234, '234'), (-1.234, '-1'), (-0.567, '-1'), (-234, '-234')], [(1.234, '1.23'), (0.567, '0.57'), (234, '234.00'), (-1.234, '-1.23'), (-0.567, '-0.57'), (-234, '-234.00')], [(1.234, '0'), (0.567, '0'), (234, '200'), (-1.234, '0'), (-0.567, '0'), (-234, '-200')], [(1.234, '3'), (0.567, '3'), (234, '234'), (-1.234, '-3'), (-0.567, '-3'), (-234, '-234')], [(1.234, '3'), (0.567, '3'), (234, '204'), (-1.234, '3'), (-0.567, '3'), (-234, '-204')]]



# Problem2:

Code:

```python
from scipy import linalg
import numpy as np

A = np.array([[1, 0, -3, 0, 5], [4, -1, 3, -2, 9], [0, 3, 2, -5, 1], [0, 0, 1, -4, 7], [9, 8, 7, 6, 5]])  # 系数矩阵
b = np.array([1, 2, 3, 4, 5])  # 常数列
X = linalg.solve(A, b)  # 求解
print(X)
```

Run example:

![image-20221117191839885](.\Answer_fyy.assets\image-20221117191839885.png)



# Problem3:

Code:

```matlab
Sum[1/(n^s), {n, 1, N[Infinity]}]
```

Run example:

![image-20221117190222049](.\Answer_fyy.assets\image-20221117190222049.png)

```matlab
[u,v] = meshgrid([0:pi/2]);
x = cos(v).*(6-(5/4+sin(3.*u)).*sin(u-3.*v))
y = sin(v).*(6-(5/4+sin(3.*u)).*sin(u-3.*v))
z = -cos(u-3.*v).*((5/4+sin(3.*u)))
surf(x, y, z, 'FaceColor', 'red', 'EdgeColor', 'none');
```



# Problem4:

Code:

```matlab
Sum[1/(n^2), {i, 0, N[Infinity]}]
```

Run example:

![image-20221117190153479](.\Answer_fyy.assets\image-20221117190153479.png)

![image-20221117190157263](.\Answer_fyy.assets\image-20221117190157263.png)

![image-20221117190201129](.\Answer_fyy.assets\image-20221117190201129.png)

![image-20221117190205287](.\Answer_fyy.assets\image-20221117190205287.png)

![image-20221117190208234](.\Answer_fyy.assets\image-20221117190208234.png)

# Problem5:

The **Riemann zeta function** or **Euler-Riemann zeta function**, denoted by the Greek letter $\zeta $ (zeta), is a mathematical function of a complex variable$s=\sigma +it$ defined as
$$
\zeta(s)=\sum_{n=1}^{\infty } \frac{1}{n^s}=\frac{1}{1^s}+\frac{1}{2^s}+\frac{1}{3^s}+\cdots
$$
for $Re(s) > 1$ and its analytic continuation elsewhere. When $Re(s)=\sigma > 1$, the function can bewritten as a converging summation or integral:
$$
\zeta(s)=\sum_{n=1}^{\infty } \frac{1}{n^s}=\frac{1}{\Gamma (s)}\int_{0}^{\infty }  \frac{x^{s-1}}{e^x-1}dx
$$
where
$$
{\Gamma (s)}=\int_{0}^{\infty }x^{s-1}e^{-x}dx
$$
is the gamma function.
In 1737, the connection between the zeta function and prime numbers was discovered by Euler, who proved the identity
$$
\sum_{n=1}^{\infty}\frac{1}{n^s}=\prod_{p \text { prime }} \frac{1}{1-p^{-s}}
$$
where, by definition, the left hand side is $\zeta(s)$ and the infinite product on the right hand side extends over all prime numbers $p$ (such expressions are called Euler products):
$$
\prod_{p \text { prime }} \frac{1}{1-p^{-s}}=\frac{1}{1-2^{-s}} \cdot \frac{1}{1-3^{-s}} \cdot \frac{1}{1-5^{-s}} \cdot \frac{1}{1-7^{-s}} \cdot \frac{1}{1-11^{-s}} \cdots \frac{1}{1-p^{-s}} \cdots
$$
Both sides of the Euler product formula converge for $Re(s) > 1$.