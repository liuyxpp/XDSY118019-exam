"""Runnable PyTorch MLP scaffold; edit features and experiment settings in src/."""
import copy
import json
import os
from pathlib import Path
import numpy as np
import torch
from sklearn.model_selection import GroupShuffleSplit
from src.course_data import clean_records, structure_group
from src.features import feature_matrix, FEATURE_NAMES


def network(n_features, width):
    return torch.nn.Sequential(torch.nn.Linear(n_features, width), torch.nn.ReLU(),
                               torch.nn.Linear(width, width), torch.nn.ReLU(),
                               torch.nn.Linear(width, 1))


def metrics(truth, pred):
    return {'mae': float(np.mean(abs(pred-truth))),
            'mape_percent': float(100*np.mean(abs(pred-truth)/truth)),
            'log_mae': float(np.mean(abs(np.log10(pred)-np.log10(truth))))}


def train_model(records, artifact_dir: Path, seed: int):
    """Split before scaling; select the checkpoint with minimum validation loss."""
    torch.set_num_threads(2)
    torch.use_deterministic_algorithms(True)
    settings = json.loads((Path(__file__).parent/'src/training_config.json').read_text())
    fraction = settings['validation_fraction']
    if not 0 < fraction < 1:
        raise ValueError('Choose a validation fraction between 0 and 1')
    x = feature_matrix(records).astype(np.float32)
    y = np.log10([r['targets']['chiN_star'] for r in records]).astype(np.float32)
    groups = [structure_group(r)[0] for r in records]
    train, val = next(GroupShuffleSplit(n_splits=1, test_size=fraction,
                                       random_state=seed).split(x, y, groups))
    mean, std = x[train].mean(0), x[train].std(0)
    std[std < 1e-8] = 1
    ym, ys = float(y[train].mean()), max(float(y[train].std()), 1e-8)
    xx = torch.from_numpy((x-mean)/std)
    yy = torch.from_numpy(((y-ym)/ys)[:, None])
    output = Path('experiments'); output.mkdir(exist_ok=True)
    results = []; selected = None; best_loss = float('inf'); names = set()
    for config in settings['configs']:
        name, width = config['name'], int(config['width'])
        if not name.replace('_', '').isalnum() or name in names or not 1 <= width <= 256:
            raise ValueError('Use unique simple run names and width between 1 and 256')
        names.add(name)
        if not 1 <= int(config['epochs']) <= 5000 or not 0 < config['lr'] <= 1:
            raise ValueError('Invalid epochs or learning rate')
        torch.manual_seed(seed)
        model = network(x.shape[1], width)
        optimizer = torch.optim.Adam(model.parameters(), lr=config['lr'])
        loss_fn = torch.nn.MSELoss()
        history = {'epoch': [], 'train_loss': [], 'val_loss': []}
        checkpoint = None; minimum = float('inf'); best_epoch = 0
        for epoch in range(1, int(config['epochs'])+1):
            model.train(); optimizer.zero_grad()
            loss = loss_fn(model(xx[train]), yy[train])
            loss.backward(); optimizer.step()
            # Same updated weights and the same normalized log-MSE for both curves.
            model.eval()
            with torch.no_grad():
                tl = float(loss_fn(model(xx[train]), yy[train]))
                vl = float(loss_fn(model(xx[val]), yy[val]))
            if not np.isfinite([tl, vl]).all():
                raise ValueError('Nonfinite loss: check features and learning rate')
            history['epoch'].append(epoch)
            history['train_loss'].append(tl); history['val_loss'].append(vl)
            if vl < minimum:
                minimum, best_epoch = vl, epoch
                checkpoint = copy.deepcopy(model.state_dict())
        model.load_state_dict(checkpoint); model.eval()
        with torch.no_grad():
            pred = np.power(10., np.clip(model(xx[val]).numpy().ravel()*ys+ym, -12, 12))
        result = {'name': name, 'config': config, 'best_epoch': best_epoch,
                  'best_val_loss': minimum, 'metrics': metrics(10.**y[val], pred), 'history': history}
        (output/f'{name}.json').write_text(json.dumps(result, allow_nan=False), encoding='utf8')
        results.append(result)
        if minimum < best_loss:
            best_loss = minimum
            selected = {'state_dict': checkpoint, 'width': width, 'n_features': x.shape[1],
                        'x_mean': mean.tolist(), 'x_std': std.tolist(), 'y_mean': ym, 'y_std': ys,
                        'feature_names': FEATURE_NAMES, 'run_name': name, 'epoch': best_epoch}
    if selected is None:
        raise ValueError('At least one experiment is required')
    artifact_dir = Path(artifact_dir); artifact_dir.mkdir(parents=True, exist_ok=True)
    torch.save(selected, artifact_dir/'model.pt')
    return {'seed': seed, 'validation_fraction': fraction,
            'split_method': 'GroupShuffleSplit on provided structural keys',
            'train_ids': [records[i]['sample_id'] for i in train],
            'val_ids': [records[i]['sample_id'] for i in val],
            'group_overlap': len({groups[i] for i in train}&{groups[i] for i in val}),
            'preprocessing_fit': 'training partition only',
            'loss_definition': 'MSE of standardized log10(chiN_star)',
            'selection': 'minimum validation loss across configurations and epochs',
            'selected_run': selected['run_name'], 'selected_epoch': selected['epoch'],
            'full_refit': False,
            'runs': [{k: v for k, v in r.items() if k != 'history'} for r in results]}


def load_model(artifact_dir: Path):
    device = os.environ.get('COURSE_DEVICE', 'cpu')
    if device not in ('cpu', 'cuda'):
        raise ValueError('COURSE_DEVICE must be cpu or cuda')
    saved = torch.load(Path(artifact_dir)/'model.pt', map_location='cpu', weights_only=True)
    if saved['feature_names'] != FEATURE_NAMES:
        raise ValueError('Feature names differ from saved weights: retrain')
    model = network(saved['n_features'], saved['width'])
    model.load_state_dict(saved['state_dict']); model.to(device); model.eval()
    return model, saved, device


def predict(model, samples):
    net, saved, device = model
    if not samples:
        return []
    x = (feature_matrix(samples)-np.asarray(saved['x_mean']))/np.asarray(saved['x_std'])
    with torch.no_grad():
        z = net(torch.as_tensor(x, dtype=torch.float32, device=device)).cpu().numpy().ravel()
    return np.power(10., np.clip(z*saved['y_std']+saved['y_mean'], -12, 12)).tolist()
