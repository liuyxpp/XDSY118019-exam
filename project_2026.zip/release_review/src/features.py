"""TASK: explain these inputs; optionally add one structural descriptor."""
import numpy as np

FEATURE_NAMES = ['n_blocks', 'fraction_A', 'min_length', 'max_length']


def feature_matrix(records):
    rows = []
    for record in records:
        blocks = record['blocks']
        lengths = [float(b['length']) for b in blocks]
        rows.append([len(blocks), sum(b['length'] for b in blocks if b['segment'] == 'A'),
                     min(lengths), max(lengths)])
    return np.asarray(rows, dtype=np.float32).reshape(len(records), len(FEATURE_NAMES))
