"""Provided structural validation and grouping utilities; no prediction model."""
import collections
import hashlib
import itertools
import math

def positive_number(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return False
    try:
        return math.isfinite(value) and value > 0
    except (OverflowError, TypeError):
        return False


def record_issues(record):
    """Return explicit issues instead of using assertions for input validation."""
    if not isinstance(record, dict):
        return ['record_not_object']
    problems = []
    if not isinstance(record.get('sample_id'), str) or not record['sample_id'].strip():
        problems.append('invalid_sample_id')
    blocks = record.get('blocks')
    if not isinstance(blocks, list) or not blocks:
        return problems + ['missing_or_empty_blocks']
    adjacency = collections.defaultdict(set)
    lengths = []
    for index, block in enumerate(blocks, 1):
        if not isinstance(block, dict):
            problems.append(f'block_{index}_not_object')
            continue
        if not isinstance(block.get('label'), str) or not block['label'].strip():
            problems.append(f'block_{index}_label')
        if block.get('segment') not in ('A', 'B'):
            problems.append(f'block_{index}_segment')
        if positive_number(block.get('length')):
            lengths.append(float(block['length']))
        else:
            problems.append(f'block_{index}_length')
        ends = block.get('ends')
        if (not isinstance(ends, list) or len(ends) != 2
                or any(not isinstance(x, str) or not x for x in ends)):
            problems.append(f'block_{index}_ends')
            continue
        left, right = ends
        if left == right:
            problems.append(f'block_{index}_self_loop')
        adjacency[left].add(right)
        adjacency[right].add(left)
    if len(lengths) == len(blocks) and not math.isclose(
            math.fsum(lengths), 1.0, rel_tol=0, abs_tol=1e-8):
        problems.append('length_sum_not_one')
    if adjacency:
        reached, pending = set(), [next(iter(adjacency))]
        while pending:
            node = pending.pop()
            if node not in reached:
                reached.add(node)
                pending.extend(adjacency[node] - reached)
        if len(reached) != len(adjacency):
            problems.append('disconnected_graph')
    targets = record.get('targets')
    if not isinstance(targets, dict) or not positive_number(targets.get('chiN_star')):
        problems.append('missing_or_invalid_chiN_star')
    return problems


def structure_group(record):
    """Identity invariant to node/block names, edge order and a global A/B swap.

    The course's small trees have an exact rooted-tree representation. Small
    cyclic graphs use exact permutations. Larger cyclic graphs use a conservative
    WL grouping, and are never deduplicated on that approximate key alone.
    No target value or sample identifier enters this structural calculation.
    """
    blocks = record['blocks']
    adjacency = collections.defaultdict(list)
    for block in blocks:
        left, right = block['ends']
        adjacency[left].append((right, block))
        adjacency[right].append((left, block))
    nodes = sorted(adjacency)

    def edge_color(block, flip):
        segment = block['segment']
        if flip:
            segment = 'B' if segment == 'A' else 'A'
        return segment, float(block['length']).hex()

    if len(blocks) == len(nodes) - 1:
        def rooted(node, parent, flip):
            return tuple(sorted(
                (*edge_color(block, flip), rooted(other, node, flip))
                for other, block in adjacency[node] if other != parent
            ))
        representation = min(rooted(node, None, flip)
                             for node in nodes for flip in (False, True))
        exact = True
    elif len(nodes) <= 8:
        representations = []
        for ordering in itertools.permutations(nodes):
            position = {node: index for index, node in enumerate(ordering)}
            for flip in (False, True):
                edges = [(*sorted(position[x] for x in block['ends']),
                          *edge_color(block, flip)) for block in blocks]
                representations.append(tuple(sorted(edges)))
        representation = min(representations)
        exact = True
    else:
        variants = []
        for flip in (False, True):
            colors = {node: str(len(adjacency[node])) for node in nodes}
            for _ in range(len(nodes)):
                colors = {node: hashlib.sha256(repr((colors[node], sorted(
                    (edge_color(block, flip), colors[other])
                    for other, block in adjacency[node]))).encode()).hexdigest()
                    for node in nodes}
            variants.append(tuple(sorted(colors.values())))
        representation, exact = min(variants), False
    key = hashlib.sha256(repr(representation).encode()).hexdigest()
    return key, exact


def clean_records(records):
    """Reject malformed/conflicting rows, then deduplicate exact equivalences.

    All rules are independent of prediction error. Conflicting IDs or equivalent
    structures with inconsistent targets are rejected rather than guessed.
    """
    candidates, logs = [], []
    for index, record in enumerate(records, 1):
        problems = record_issues(record)
        sample_id = record.get('sample_id') if isinstance(record, dict) else None
        if problems:
            logs.append(dict(record_index=index, sample_id=sample_id,
                             issue=','.join(problems), action='reject'))
        else:
            group, exact = structure_group(record)
            candidates.append((index, record, group, exact))
    by_id, by_exact_group = collections.defaultdict(list), collections.defaultdict(list)
    for row in candidates:
        by_id[row[1]['sample_id']].append(row)
        if row[3]:
            by_exact_group[row[2]].append(row)
    conflicts = set()
    for rows in list(by_id.values()) + list(by_exact_group.values()):
        first = rows[0]
        if any(row[2] != first[2] or not math.isclose(
                row[1]['targets']['chiN_star'], first[1]['targets']['chiN_star'],
                rel_tol=1e-6, abs_tol=1e-8) for row in rows):
            conflicts.update(row[0] for row in rows)
    clean, kept_ids, kept_groups = [], set(), set()
    for index, record, group, exact in candidates:
        if index in conflicts:
            issue, action = 'conflicting_identity_or_target', 'reject_ambiguous_group'
        elif record['sample_id'] in kept_ids or exact and group in kept_groups:
            issue, action = 'duplicate_or_equivalent_structure', 'keep_first'
        else:
            clean.append(record)
            kept_ids.add(record['sample_id'])
            if exact:
                kept_groups.add(group)
            continue
        logs.append(dict(record_index=index, sample_id=record['sample_id'],
                         issue=issue, action=action))
    return clean, sorted(logs, key=lambda item: item['record_index'])
