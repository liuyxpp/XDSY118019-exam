"""Local training entry point. Edit solution.py to implement your method."""
import argparse,json
from pathlib import Path
from solution import clean_records,train_model

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--data',type=Path,default=Path('data/dataset.json'));ap.add_argument('--artifacts',type=Path,default=Path('artifacts'));ap.add_argument('--seed',type=int,default=20261105);a=ap.parse_args()
    records=json.loads(a.data.read_text(encoding='utf8'));clean,log=clean_records(records)
    if not isinstance(clean,list) or not clean:raise ValueError('clean_records must return a nonempty list')
    a.artifacts.mkdir(parents=True,exist_ok=True);Path('experiments').mkdir(exist_ok=True)
    Path('experiments/cleaning_log.json').write_text(json.dumps(log,ensure_ascii=False,indent=2),encoding='utf8')
    summary=train_model(clean,a.artifacts,a.seed)
    Path('experiments/summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps({'input_records':len(records),'clean_records':len(clean),'seed':a.seed}))

if __name__=='__main__':main()
