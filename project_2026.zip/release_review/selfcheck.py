"""Public synthetic interface test, not a hidden-set evaluation or cleaning test."""
import argparse,os,json,math,subprocess,sys,tempfile
from pathlib import Path

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--artifacts',type=Path,default=Path('artifacts'));ap.add_argument('--device',choices=['cpu','cuda'],default='cpu');a=ap.parse_args()
    samples=[{'sample_id':'interface_example_1','blocks':[{'label':'b1','length':.4,'segment':'A','ends':['N1','N2']},{'label':'b2','length':.6,'segment':'B','ends':['N2','N3']}]},
             {'sample_id':'interface_example_2','blocks':[{'label':'b1','length':.2,'segment':'A','ends':['N1','N2']},{'label':'b2','length':.5,'segment':'B','ends':['N1','N3']},{'label':'b3','length':.3,'segment':'A','ends':['N1','N4']}]}]
    with tempfile.TemporaryDirectory() as tmp:
        t=Path(tmp);(t/'input.json').write_text(json.dumps(samples),encoding='utf8')
        cmd=[sys.executable,'predict.py','--input',str(t/'input.json'),'--output',str(t/'output.json'),'--artifacts',str(a.artifacts.resolve())]
        subprocess.run(cmd,check=True,timeout=180,env=dict(os.environ,COURSE_DEVICE=a.device));rows=json.loads((t/'output.json').read_text())
        if not isinstance(rows,list) or len(rows)!=len(samples):raise ValueError('Invalid output length')
        expected={s['sample_id'] for s in samples}
        if {s['sample_id'] for s in rows}!=expected:raise ValueError('Wrong/duplicate IDs')
        if not all(set(s)=={'sample_id','chiN_star'} and isinstance(s['chiN_star'],(int,float)) and not isinstance(s['chiN_star'],bool) and math.isfinite(s['chiN_star']) and s['chiN_star']>0 for s in rows):raise ValueError('Invalid output values')
    print('PASS: input/output contract on two synthetic structures. This does not certify model accuracy.')

if __name__=='__main__':main()
