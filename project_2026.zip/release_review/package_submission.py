"""Create an explicit allowlist ZIP; never package datasets, tokens or .git."""
import argparse,hashlib,json,re,zipfile
from pathlib import Path
REQUIRED=['predict.py','solution.py','train.py','requirements.txt','submission.json','report.md','AI_USAGE.md','experiments/cleaning_log.json','experiments/summary.json']

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path('submission.zip'));a=ap.parse_args();root=Path.cwd().resolve()
    meta=json.loads(Path('submission.json').read_text(encoding='utf8'))
    if meta.get('schema_version')!=1 or not re.fullmatch(r'[A-Za-z0-9_-]{1,64}',meta.get('student_id','')) or meta['student_id']=='REPLACE_ME':raise ValueError('Fill student_id')
    files=[root/p for p in REQUIRED]
    for folder in ['artifacts','experiments','src','figures']:
        p=root/folder
        if p.exists():files.extend(f for f in p.rglob('*') if f.is_file() and '__pycache__' not in f.parts)
    files=sorted(set(files))
    if any(not p.is_file() or p.is_symlink() or not p.resolve().is_relative_to(root) for p in files):raise ValueError('Missing files or unsafe paths')
    artifacts=[p for p in files if p.relative_to(root).parts[0]=='artifacts' and p.name!='README.md']
    if not artifacts:raise ValueError('Save model weights in artifacts/')
    if sum(p.stat().st_size for p in files)>50*1024*1024:raise ValueError('Submission exceeds 50 MiB uncompressed limit')
    manifest={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    if a.output.resolve() in files:raise ValueError('ZIP cannot contain itself')
    with zipfile.ZipFile(a.output,'w',zipfile.ZIP_DEFLATED) as z:
        for p in files:z.write(p,p.relative_to(root))
        z.writestr('submission_manifest.json',json.dumps(manifest,indent=2))
    print(json.dumps({'zip':str(a.output),'sha256':hashlib.sha256(a.output.read_bytes()).hexdigest(),'files':len(files)}))

if __name__=='__main__':main()
