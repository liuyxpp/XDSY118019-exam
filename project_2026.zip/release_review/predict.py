"""Fixed evaluator entry point: python predict.py --input X --output Y --artifacts Z."""
import argparse,json,math
from pathlib import Path
from solution import load_model,predict

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--input',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--artifacts',type=Path,default=Path('artifacts'));a=ap.parse_args()
    samples=json.loads(a.input.read_text(encoding='utf8'))
    # Discard labels even during local self-checks.
    query=[{'sample_id':s['sample_id'],'blocks':s['blocks']} for s in samples]
    model=load_model(a.artifacts);values=[float(v) for v in predict(model,query)]
    if len(values)!=len(query) or not all(math.isfinite(v) and v>0 for v in values):raise ValueError('Need one positive finite prediction per input')
    rows=[{'sample_id':s['sample_id'],'chiN_star':v} for s,v in zip(query,values)]
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(rows,allow_nan=False),encoding='utf8')

if __name__=='__main__':main()
