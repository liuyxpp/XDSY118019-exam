import math
import numpy as np
from scipy.linalg import norm

def _validate_vector(u, dtype=None):
    u = np.asarray(u, dtype=dtype, order='c')
    if u.ndim == 1:
        return u
    raise ValueError("Input vector should be 1-D.")


def _validate_weights(w, dtype=np.float64):
    w = _validate_vector(w, dtype=dtype)
    if np.any(w < 0):
        raise ValueError("Input weights should be all non-negative")
    return w


def minkowski(u, v, p=2, w=None):
    """
    Compute the Minkowski distance between two 1-D arrays.

    The Minkowski distance between 1-D arrays `u` and `v`,
    is defined as

    .. math::

       {\\|u-v\\|}_p = (\\sum{|u_i - v_i|^p})^{1/p}.


       \\left(\\sum{w_i(|(u_i - v_i)|^p)}\\right)^{1/p}.

    Parameters
    ----------
    u : (N,) array_like
        Input array.
    v : (N,) array_like
        Input array.
    p : scalar
        The order of the norm of the difference :math:`{\\|u-v\\|}_p`. Note
        that for :math:`0 < p < 1`, the triangle inequality only holds with
        an additional multiplicative factor, i.e. it is only a quasi-metric.
    w : (N,) array_like, optional
        The weights for each value in `u` and `v`. Default is None,
        which gives each value a weight of 1.0

    Returns
    -------
    minkowski : double
        The Minkowski distance between vectors `u` and `v`.

    Examples
    --------
    >>> float(minkowski([1, 0, 0], [0, 1, 0], 1))
    2.0

    # Added for Q1(ii): Example 1 - Euclidean distance (p=2)
    >>> float(minkowski([1, 2], [4, 6]))
    5.0

    # Added for Q1(ii): Example 2 - Manhattan distance (p=1)
    >>> float(minkowski([1, 2], [4, 6], p=1))
    7.0

    # Added for Q1(ii): Example 3 - Chebyshev distance (p=infinity)
    >>> float(minkowski([1, 2], [4, 6], p=np.inf))
    4.0

    # Added for Q1(ii): Example 4 - Weighted distance
    >>> float(minkowski([1, 2], [4, 6], p=1, w=[1, 2]))
    11.0

    # Added for Q1(ii): Example 5 - Identical vectors
    >>> float(minkowski([1, 2, 3], [1, 2, 3]))
    0.0

    """

    # Added for Q1(i): validate input vectors u and v
    u = _validate_vector(u, dtype=np.float64)
    v = _validate_vector(v, dtype=np.float64)

    # Added for Q1(i): check that u and v have the same length
    if u.shape != v.shape:
        raise ValueError("Input vectors must have the same length.")

    # Added for Q1(i): validate parameter p
    if (isinstance(p, (bool, np.bool_))
            or not isinstance(p, (int, float, np.integer, np.floating))
            or np.isnan(p) or p <= 0):
        raise ValueError("p must be a positive real number.")

    # Added for Q1(i): validate weights w
    if w is not None:
        w = _validate_weights(w)
        if w.shape != u.shape:
            raise ValueError("Weights must have the same length as u and v.")


    u_v = u - v
    if w is not None:
        if p == 1:
            root_w = w
        elif p == 2:
            # better precision and speed
            root_w = np.sqrt(w)
        elif p == np.inf:
            root_w = (w != 0)
        else:
            root_w = np.power(w, 1/p)
        u_v = root_w * u_v
    dist = norm(u_v, ord=p)
    return dist


if __name__ == '__main__':
    # Added for Q1(iii): Case 1 - Weighted Minkowski distance
    u1 = [1, 2, 3]
    v1 = [3, 2, 1]
    result1 = minkowski(u1, v1, p=2, w=[0.1, 0.7, 0.2])
    print(f"Case 1: {result1:.6f}")

    # Added for Q1(iii): Case 2 - Minkowski distance with p=0.5
    u2 = [0, 1, 1, 0, 0, 1]
    v2 = [1, 0, 0, 1, 1, 0]
    result2 = minkowski(u2, v2, p=0.5)
    print(f"Case 2: {result2:.6f}")

    # Added for Q1(iii): Case 3 - Minkowski distance with p=3
    u3 = [0.1, 0.5, -0.3, -1.2]
    v3 = [-0.5, 1.5, 0.3, 0.6]
    result3 = minkowski(u3, v3, p=3)
    print(f"Case 3: {result3:.6f}")

