
% Question 2: Klein Bottle Visualization
% Render a 3D Klein bottle using the surf function.

clear;
clc;
close all;

% Added for Q2: Define parameter ranges
n = 160;
u = (0:n-1) * 2*pi/n;
v = (0:n-1) * 2*pi/n;
[U, V] = meshgrid(u, v);

% Added for Q2: Calculate x(u,v)
X = -(2/15) .* cos(U) .* ( ...
    3*cos(V) ...
    - 30*sin(U) ...
    + 90*cos(U).^4 .* sin(U) ...
    - 60*cos(U).^6 .* sin(U) ...
    + 5*cos(U).*cos(V).*sin(U) );

% Added for Q2: Calculate y(u,v)
Y = -(1/15) .* sin(U) .* ( ...
    3*cos(V) ...
    - 3*cos(U).^2 .* cos(V) ...
    - 48*cos(U).^4 .* cos(V) ...
    + 48*cos(U).^6 .* cos(V) ...
    - 60*sin(U) ...
    + 5*cos(U).*cos(V).*sin(U) ...
    - 5*cos(U).^3 .* cos(V).*sin(U) ...
    - 80*cos(U).^5 .* cos(V).*sin(U) ...
    + 80*cos(U).^7 .* cos(V).*sin(U) );

% Added for Q2: Calculate z(u,v)
Z = (2/15) .* ( ...
    3 + 5*cos(U).*sin(U) ) .* sin(V);

% Added for Q2: Render the 3D surface using surf
figure('Color', 'w');
surf(X, Y, Z, 'EdgeColor', 'none');

% Added for Q2: Improve visualization
shading interp;
colormap(turbo);
axis equal;
axis tight;
grid on;
xlabel('X');
ylabel('Y');
zlabel('Z');
title('Klein Bottle');
view(45, 25);
camlight('headlight');
lighting gouraud;

% Added for Q2: Save the generated figure
saveas(gcf, 'klein_bottle.png');
