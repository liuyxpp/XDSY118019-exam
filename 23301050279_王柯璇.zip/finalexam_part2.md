
# Final Examination — Part 2

## Question 1: Python Programming

### (i) Input Validation

The function validates the input vectors u and v, the order p, and the optional weights w.

### (ii) Usage Examples

Five additional usage examples have been included in the docstring.

### (iii) Calculation Results

| Case | Minkowski Distance |
|------|-------------------:|
| 1 | 1.095445 |
| 2 | 36.000000 |
| 3 | 1.936683 |

### Complete Python Source Code

``` python
import math
import numpy as np
from scipy.linalg import norm

def _validate_vector(u, dtype=None):
    u = np.asarray(u, dtype=dtype, order='c')
    if u.ndim == 1:
        return u
    raise ValueError("Input vector should be 1-D.")


def _validate_weights(w, dtype=np.float64):
    w = _validate_vector(w, dtype=dtype)
    if np.any(w < 0):
        raise ValueError("Input weights should be all non-negative")
    return w


def minkowski(u, v, p=2, w=None):
    """
    Compute the Minkowski distance between two 1-D arrays.

    The Minkowski distance between 1-D arrays `u` and `v`,
    is defined as

    .. math::

       {\\|u-v\\|}_p = (\\sum{|u_i - v_i|^p})^{1/p}.


       \\left(\\sum{w_i(|(u_i - v_i)|^p)}\\right)^{1/p}.

    Parameters
    ----------
    u : (N,) array_like
        Input array.
    v : (N,) array_like
        Input array.
    p : scalar
        The order of the norm of the difference :math:`{\\|u-v\\|}_p`. Note
        that for :math:`0 < p < 1`, the triangle inequality only holds with
        an additional multiplicative factor, i.e. it is only a quasi-metric.
    w : (N,) array_like, optional
        The weights for each value in `u` and `v`. Default is None,
        which gives each value a weight of 1.0

    Returns
    -------
    minkowski : double
        The Minkowski distance between vectors `u` and `v`.

    Examples
    --------
    >>> float(minkowski([1, 0, 0], [0, 1, 0], 1))
    2.0

    # Added for Q1(ii): Example 1 - Euclidean distance (p=2)
    >>> float(minkowski([1, 2], [4, 6]))
    5.0

    # Added for Q1(ii): Example 2 - Manhattan distance (p=1)
    >>> float(minkowski([1, 2], [4, 6], p=1))
    7.0

    # Added for Q1(ii): Example 3 - Chebyshev distance (p=infinity)
    >>> float(minkowski([1, 2], [4, 6], p=np.inf))
    4.0

    # Added for Q1(ii): Example 4 - Weighted distance
    >>> float(minkowski([1, 2], [4, 6], p=1, w=[1, 2]))
    11.0

    # Added for Q1(ii): Example 5 - Identical vectors
    >>> float(minkowski([1, 2, 3], [1, 2, 3]))
    0.0

    """

    # Added for Q1(i): validate input vectors u and v
    u = _validate_vector(u, dtype=np.float64)
    v = _validate_vector(v, dtype=np.float64)

    # Added for Q1(i): check that u and v have the same length
    if u.shape != v.shape:
        raise ValueError("Input vectors must have the same length.")

    # Added for Q1(i): validate parameter p
    if (isinstance(p, (bool, np.bool_))
            or not isinstance(p, (int, float, np.integer, np.floating))
            or np.isnan(p) or p <= 0):
        raise ValueError("p must be a positive real number.")

    # Added for Q1(i): validate weights w
    if w is not None:
        w = _validate_weights(w)
        if w.shape != u.shape:
            raise ValueError("Weights must have the same length as u and v.")

    u_v = u - v
    if w is not None:
        if p == 1:
            root_w = w
        elif p == 2:
            # better precision and speed
            root_w = np.sqrt(w)
        elif p == np.inf:
            root_w = (w != 0)
        else:
            root_w = np.power(w, 1/p)
        u_v = root_w * u_v
    dist = norm(u_v, ord=p)
    return dist

if __name__ == '__main__':
    # Added for Q1(iii): Case 1 - Weighted Minkowski distance
    u1 = [1, 2, 3]
    v1 = [3, 2, 1]
    result1 = minkowski(u1, v1, p=2, w=[0.1, 0.7, 0.2])
    print(f"Case 1: {result1:.6f}")

    # Added for Q1(iii): Case 2 - Minkowski distance with p=0.5
    u2 = [0, 1, 1, 0, 0, 1]
    v2 = [1, 0, 0, 1, 1, 0]
    result2 = minkowski(u2, v2, p=0.5)
    print(f"Case 2: {result2:.6f}")

    # Added for Q1(iii): Case 3 - Minkowski distance with p=3
    u3 = [0.1, 0.5, -0.3, -1.2]
    v3 = [-0.5, 1.5, 0.3, 0.6]
    result3 = minkowski(u3, v3, p=3)
    print(f"Case 3: {result3:.6f}")

```

## Question 2: MATLAB Visualization 

### Klein Bottle

The Klein bottle was rendered using the `surf` function in MATLAB according to the given parametric equations.

### MATLAB Source Code

``` matlab
% Question 2: Klein Bottle Visualization
% Render a 3D Klein bottle using the surf function.

clear;
clc;
close all;

% Added for Q2: Define parameter ranges
n = 160;
u = (0:n-1) * 2*pi/n;
v = (0:n-1) * 2*pi/n;
[U, V] = meshgrid(u, v);

% Added for Q2: Calculate x(u,v)
X = -(2/15) .* cos(U) .* ( ...
    3*cos(V) ...
    - 30*sin(U) ...
    + 90*cos(U).^4 .* sin(U) ...
    - 60*cos(U).^6 .* sin(U) ...
    + 5*cos(U).*cos(V).*sin(U) );

% Added for Q2: Calculate y(u,v)
Y = -(1/15) .* sin(U) .* ( ...
    3*cos(V) ...
    - 3*cos(U).^2 .* cos(V) ...
    - 48*cos(U).^4 .* cos(V) ...
    + 48*cos(U).^6 .* cos(V) ...
    - 60*sin(U) ...
    + 5*cos(U).*cos(V).*sin(U) ...
    - 5*cos(U).^3 .* cos(V).*sin(U) ...
    - 80*cos(U).^5 .* cos(V).*sin(U) ...
    + 80*cos(U).^7 .* cos(V).*sin(U) );

% Added for Q2: Calculate z(u,v)
Z = (2/15) .* ( ...
    3 + 5*cos(U).*sin(U) ) .* sin(V);

% Added for Q2: Render the 3D surface using surf
figure('Color', 'w');
surf(X, Y, Z, 'EdgeColor', 'none');

% Added for Q2: Improve visualization
shading interp;
colormap(turbo);
axis equal;
axis tight;
grid on;
xlabel('X');
ylabel('Y');
zlabel('Z');
title('Klein Bottle');
view(45, 25);
camlight('headlight');
lighting gouraud;

% Added for Q2: Save the generated figure
saveas(gcf, 'klein_bottle.png');

```

### Visualization Result

![Klein Bottle](klein_bottle.png)

## Question 3: Mathematica 

### (i) Infinite Series

Evaluate the infinite series:

$$
\sum_{n=1}^{\infty}\frac{(-1)^{n+1}\sin n}{n}
$$

Mathematica code:

```mathematica
(* Q3(i): Calculate the infinite series *)
seriesResult = Sum[(-1)^(n + 1) * Sin[n]/n, {n, 1, Infinity}];
Chop[N[seriesResult, 10]]
```

Result:

$$
\boxed{0.5}
$$

### (ii) Indefinite Integral

Evaluate the integral:

$$
\int \sqrt{\tan x}\,dx
$$

Mathematica code:

```mathematica
(* Q3(ii): Calculate the indefinite integral *)
integralResult = Integrate[Sqrt[Tan[x]], x, Assumptions -> 0 < x < Pi/2];
integralResult
```

Result (for $0<x<\pi/2$):

Let $t=\sqrt{\tan x}$. Then

$$
\int \sqrt{\tan x}\,dx
=
\frac{1}{2\sqrt{2}}
\ln\left(\frac{t^2-\sqrt{2}t+1}{t^2+\sqrt{2}t+1}\right)
+\frac{1}{\sqrt{2}}
\left[
\arctan(\sqrt{2}t-1)
+\arctan(\sqrt{2}t+1)
\right]+C
$$

### Mathematica Results

The following screenshot shows the calculation results obtained using Wolfram Cloud.

![Mathematica Results](mathematica_results.png)


---

## Question 4: Markdown Typesetting 

# **Navier–Stokes Equations**

The Navier–Stokes momentum equation can be derived as a particular form of the Cauchy momentum equation, whose general convective form is:

$$
\frac{D\mathbf{u}}{Dt} =
\frac{1}{\rho}\nabla\cdot\boldsymbol{\sigma}
+\mathbf{a}.
$$

By setting the Cauchy stress tensor $\boldsymbol{\sigma}$ to be the sum of a viscosity term $\boldsymbol{\tau}$ (the deviatoric stress) and a pressure term $-p\mathbf{I}$ (volumetric stress), we arrive at:

$$
\rho\frac{D\mathbf{u}}{Dt}
=-\nabla p+\nabla\cdot\boldsymbol{\tau}+\rho\mathbf{a}
$$

where

- $\frac{D}{Dt}$ is the material derivative, defined as $\frac{\partial}{\partial t}+\mathbf{u}\cdot\nabla$,
- $\rho$ is the (mass) density,
- $\mathbf{u}$ is the flow velocity,
- $\nabla\cdot$ is the divergence,
- $p$ is the pressure,
- $t$ is time,
- $\boldsymbol{\tau}$ is the Deviatoric stress|deviatoric stress tensor, which has order 2,
- $\mathbf{a}$ represents body forces acting on the continuum, for example gravity, Fictitious force|inertial accelerations, Coulomb's law|electrostatic accelerations, and so on.

In this form, it is apparent that in the assumption of an inviscid fluid – no deviatoric stress – Cauchy equations reduce to the [Euler equations](https://en.wikipedia.org/wiki/Euler_equations_(fluid_dynamics)).


