% q2_klein_bottle.m
% Render a Klein bottle with MATLAB's surf function.
% The parametrisation is the one given in the exam question.

clear; clc; close all;

nu = 181;  nv = 181;
u = linspace(0, 2*pi, nu);
v = linspace(0, 2*pi, nv);
[U, V] = meshgrid(u, v);

X = -(2/15).*cos(U).*(3*cos(V) - 30*sin(U) ...
    + 90*cos(U).^4.*sin(U) - 60*cos(U).^6.*sin(U) ...
    + 5*cos(U).*cos(V).*sin(U));

Y = -(1/15).*sin(U).*(3*cos(V) - 3*cos(U).^2.*cos(V) ...
    - 48*cos(U).^4.*cos(V) + 48*cos(U).^6.*cos(V) ...
    - 60*sin(U) + 5*cos(U).*cos(V).*sin(U) ...
    - 5*cos(U).^3.*cos(V).*sin(U) ...
    - 80*cos(U).^5.*cos(V).*sin(U) ...
    + 80*cos(U).^7.*cos(V).*sin(U));

Z = (2/15).*(3 + 5*cos(U).*sin(U)).*sin(V);

% Use Y as colour data so that the bottle has a smooth bottom-to-top
% parula gradient; C = Z (the surf default) would also be valid.
C = Y;

fig = figure('Color', 'w', 'Position', [100 100 900 900]);
surf(X, Y, Z, C, 'EdgeColor', 'none', 'FaceColor', 'interp');
colormap(parula(256));
camlight('headlight');
lighting gouraud;
material dull;
axis equal;  axis off;  view(3);
set(gca, 'DataAspectRatio', [1 1 1]);

exportgraphics(fig, 'klein_bottle.png', 'Resolution', 300);
