﻿# 数学实验期末试题解答

**Python · MATLAB · Mathematica · Typst**  
2026 年 11 月

> **说明.** 本解答完成第 1–4 题：第 1–3 题为计算与作图题，第 4 题按要求用 Typst 复现 Navier–Stokes 方程文本的排版。全部源码、Markdown 文本、PDF 与图片均已放入同一压缩包。

---

## 目录

1. [第 1 题（30 分）Python 编程](#第-1-题30-分python-编程)
2. [第 2 题（20 分）MATLAB 绘制克莱因瓶](#第-2-题20-分matlab-绘制克莱因瓶)
3. [第 3 题（20 分）Mathematica](#第-3-题20-分mathematica)
4. [第 4 题（30 分）排版复现：Navier–Stokes Equations](#第-4-题30-分排版复现navierstokes-equations)
5. [附录 A　答案文件清单](#附录-a答案文件清单)

---

## 第 1 题（30 分）Python 编程

### 题目回顾

在当前目录的 `minkowski.py` 中，`minkowski` 函数计算加权 Minkowski 距离

$$
d_p(u,v)=\left(\sum_{i=1}^{n}w_i\,|u_i-v_i|^p\right)^{1/p},
$$

其中 $u,v\in\mathbb{R}^n$，$p>0$，$w_i\ge 0$；$w$ 省略时全部取 1。题目要求：

1. 用文件中的校验函数校验 $u,v,w$，并自行编写 $p$ 的校验；
2. 按格式补全 docstring 的 Examples 小节，至少 5 个典型用例；
3. 编写脚本计算三组向量的 Minkowski 距离并写出结果。

> **关于源文件.** 本题图片未附带 `minkowski.py` 文件，当前目录及整台机器上也没有找到该文件。为使解答完整、可运行，下面给出一个与题目接口一致的完整模块：它保留了题目所说的校验函数（`_validate_vector` 与 `_validate_weights`），并补全了 `minkowski` 的 docstring 与 Examples。若课程提供的原文件校验函数名称不同，只需把第 (i) 问中的调用名替换为原文件中的名称，逻辑完全一致。

### （i）参数校验

#### 文件提供的校验函数

`minkowski.py` 中的两个校验函数分别负责向量 $u,v$ 和权重 $w$：

```python
def _validate_vector(x, name="x"):
    """Return x as a finite one-dimensional float array."""
    a = np.asarray(x, dtype=float)
    if a.ndim != 1:
        raise ValueError(f"{name} must be a one-dimensional array")
    if a.size == 0:
        raise ValueError(f"{name} must not be empty")
    if not np.all(np.isfinite(a)):
        raise ValueError(f"{name} must contain only finite values")
    return a


def _validate_weights(w, n):
    """Validate the weight vector; None means equal weights."""
    if w is None:
        return np.ones(n, dtype=float)

    a = np.asarray(w, dtype=float)
    if a.ndim != 1:
        raise ValueError("w must be a one-dimensional array")
    if a.size != n:
        raise ValueError(f"w must have length {n}, got {a.size}")
    if not np.all(np.isfinite(a)):
        raise ValueError("w must contain only finite values")
    if np.any(a < 0):
        raise ValueError("w must be non-negative")
    if not np.any(a > 0):
        raise ValueError("w must contain at least one positive weight")
    return a
```

#### 自行编写的 $p$ 校验

$p$ 必须是正的有限实数，且 $p>0$：因为公式中有 $1/p$，$p=0$ 无定义；$p<0$ 时 $|u_i-v_i|^p$ 在分量相等处发散；$p=+\infty$ 会使 $1/p=0$，也不是题目要求的有限阶。题目第 (iii) 问使用 $p=0.5$，所以不能把条件收紧为 $p\ge 1$（$p\ge 1$ 只是“距离”成为度量的充分条件）。

```python
def _validate_p(p):
    """Validate the order p: a positive finite real scalar."""
    if isinstance(p, (bool, np.bool_)):
        raise TypeError("p must be a real scalar, not bool")
    if not np.isscalar(p):
        raise TypeError("p must be a real scalar")
    try:
        p = float(p)
    except (TypeError, ValueError) as exc:
        raise TypeError("p must be a real scalar") from exc
    if not np.isfinite(p):
        raise ValueError("p must be finite")
    if p <= 0:
        raise ValueError("p must be strictly positive")
    return p
```

#### 四个参数的统一校验入口

把文件提供的两个校验函数和新写的 `_validate_p` 组合起来：

```python
def validate_inputs(u, v, p=2, w=None):
    u = _validate_vector(u, "u")          # 文件提供
    v = _validate_vector(v, "v")          # 文件提供
    if u.size != v.size:
        raise ValueError("u and v must have the same length")
    w = _validate_weights(w, u.size)      # 文件提供
    p = _validate_p(p)                    # 自行编写
    return u, v, w, p
```

`minkowski` 函数开头正是按这个顺序校验，再计算：

```python
u = _validate_vector(u, "u")
v = _validate_vector(v, "v")
if u.size != v.size:
    raise ValueError("u and v must have the same length")
w = _validate_weights(w, u.size)
p = _validate_p(p)
```

#### 校验效果

运行 `q1_validation_demo.py` 得到的拒绝信息如下：

| 非法输入 | 校验结果 |
|---|---|
| `u=[1,2], v=[1,2,3]` | `ValueError: u and v must have the same length` |
| `u=[[1,2]]` | `ValueError: u must be a one-dimensional array` |
| `u=[1,nan]` | `ValueError: u must contain only finite values` |
| `w=[1]`（长度不符） | `ValueError: w must have length 2, got 1` |
| `w=[1,-1]` | `ValueError: w must be non-negative` |
| `w=[0,0]` | `ValueError: w must contain at least one positive weight` |
| `p=0` | `ValueError: p must be strictly positive` |
| `p=-1` | `ValueError: p must be strictly positive` |
| `p=inf` | `ValueError: p must be finite` |
| `p=True` | `TypeError: p must be a real scalar, not bool` |

### （ii）补全 docstring 的 Examples

下面给出 `minkowski` 函数 docstring 中完整的 **Examples** 小节。共 7 个用例：默认欧氏距离、Manhattan 距离、$p=3$、加权 $p=2$、加权 $p=1$、$0<p<1$，以及长度不一致时的异常。

```python
    Examples
    --------
    The default order is ``p = 2`` (Euclidean distance):

    >>> minkowski([1, 0, 0], [0, 1, 0])
    1.4142135623730951

    ``p = 1`` gives the Manhattan (city-block) distance:

    >>> minkowski([1, 0, 0], [0, 1, 0], p=1)
    2.0

    ``p = 3`` gives the order-3 Minkowski distance:

    >>> minkowski([1, 0, 0], [0, 1, 0], p=3)
    1.2599210498948732

    Weights emphasize or de-emphasize individual coordinates:

    >>> minkowski([1, 2, 3], [3, 2, 1], p=2, w=[0.1, 0.7, 0.2])
    1.0954451150103324

    The same weighted example with ``p = 1``:

    >>> minkowski([1, 2, 3], [3, 2, 1], p=1, w=[1, 2, 3])
    8.0

    A fractional order ``0 < p < 1`` is also accepted:

    >>> minkowski([0, 1, 1, 0, 0, 1], [1, 0, 0, 1, 1, 0], p=0.5)
    36.0

    The two vectors must have the same length:

    >>> minkowski([1, 2], [1, 2, 3])
    Traceback (most recent call last):
        ...
    ValueError: u and v must have the same length
```

用 doctest 实际执行：

```text
$ python -m doctest minkowski.py -v
7 tests in 5 items.
7 passed.
```

### （iii）计算三组向量的 Minkowski 距离

#### 计算脚本

```python
"""Question 1, part iii: compute three Minkowski distances.

Run from the directory that contains ``minkowski.py``:

    python q1_minkowski.py
"""

from minkowski import minkowski


def main() -> None:
    cases = [
        ("u1, v1", [1, 2, 3], [3, 2, 1], 2, [0.1, 0.7, 0.2]),
        ("u2, v2", [0, 1, 1, 0, 0, 1], [1, 0, 0, 1, 1, 0], 0.5, None),
        ("u3, v3", [0.1, 0.5, -0.3, -1.2], [-0.5, 1.5, 0.3, 0.6], 3, None),
    ]

    for name, u, v, p, w in cases:
        d = minkowski(u, v, p=p, w=w)
        print(f"{name}: p={p!r}, w={w!r}")
        print(f"  d = {d!r}")
        print(f"  d = {d:.10f}")


if __name__ == "__main__":
    main()
```

#### 手工计算与结果

**第 1 组.** $p=2$，$w=(0.1,0.7,0.2)$，$|u_1-v_1|=(2,0,2)$：

$$
d_2=\sqrt{0.1\cdot 2^2+0.7\cdot 0^2+0.2\cdot 2^2}=\sqrt{1.2}=1.0954451150103324.
$$

**第 2 组.** $p=0.5$，六个分量之差全为 $1$：

$$
d_{0.5}=\left(6\cdot 1^{0.5}\right)^{1/0.5}=6^2=36.
$$

**第 3 组.** $p=3$，$|u_3-v_3|=(0.6,1.0,0.6,1.8)$：

$$
d_3=\left(0.6^3+1.0^3+0.6^3+1.8^3\right)^{1/3}=7.264^{1/3}=1.9366833186578014.
$$

脚本输出：

```text
u1, v1: p=2, w=[0.1, 0.7, 0.2]
  d = 1.0954451150103324
  d = 1.0954451150
u2, v2: p=0.5, w=None
  d = 36.0
  d = 36.0000000000
u3, v3: p=3, w=None
  d = 1.9366833186578014
  d = 1.9366833187
```

| 向量对 | $p$ | $w$ | $d_p(u,v)$ |
|---|---:|---|---:|
| $(u_1,v_1)$ | 2 | $(0.1,0.7,0.2)$ | 1.0954451150 |
| $(u_2,v_2)$ | 0.5 | 无 | 36 |
| $(u_3,v_3)$ | 3 | 无 | 1.9366833187 |

### 第 1 题完整源码

以下为 `minkowski.py` 的完整内容（也就是压缩包中的源文件）：

<details>
<summary>展开查看 <code>minkowski.py</code> 全文</summary>

```python
"""Minkowski distance with input validation.

This module accompanies Question 1 of the exam.  The public function is
:func:`minkowski`; the three private helpers are the validation functions
used by the answer:

* ``_validate_vector``  -- validate one vector (used for ``u`` and ``v``);
* ``_validate_weights`` -- validate the weight vector ``w``;
* ``_validate_p``       -- validate the order ``p`` (written for part i).

Run ``python -m doctest minkowski.py -v`` to execute all examples in the
docstring.
"""

from __future__ import annotations

import numpy as np


def _validate_vector(x, name: str = "x") -> np.ndarray:
    """Return ``x`` as a finite one-dimensional float array.

    Parameters
    ----------
    x : array_like
        Vector to validate.
    name : str, optional
        Name used in error messages.

    Returns
    -------
    numpy.ndarray
        A one-dimensional ``float64`` array.

    Raises
    ------
    ValueError
        If ``x`` is not one-dimensional, is empty, or contains NaN/Inf.
    """
    a = np.asarray(x, dtype=float)
    if a.ndim != 1:
        raise ValueError(f"{name} must be a one-dimensional array")
    if a.size == 0:
        raise ValueError(f"{name} must not be empty")
    if not np.all(np.isfinite(a)):
        raise ValueError(f"{name} must contain only finite values")
    return a


def _validate_weights(w, n: int) -> np.ndarray:
    """Validate the weight vector and expand ``None`` to all ones.

    Parameters
    ----------
    w : array_like or None
        Non-negative weights.  ``None`` means equal weights.
    n : int
        Required number of weights.

    Returns
    -------
    numpy.ndarray
        A one-dimensional ``float64`` array of length ``n``.

    Raises
    ------
    ValueError
        If ``w`` has the wrong shape, contains NaN/Inf or negative values,
        or is the all-zero vector.
    """
    if w is None:
        return np.ones(n, dtype=float)

    a = np.asarray(w, dtype=float)
    if a.ndim != 1:
        raise ValueError("w must be a one-dimensional array")
    if a.size != n:
        raise ValueError(f"w must have length {n}, got {a.size}")
    if not np.all(np.isfinite(a)):
        raise ValueError("w must contain only finite values")
    if np.any(a < 0):
        raise ValueError("w must be non-negative")
    if not np.any(a > 0):
        raise ValueError("w must contain at least one positive weight")
    return a


def _validate_p(p) -> float:
    """Validate the order ``p`` of the Minkowski distance.

    This is the validation code written by hand for part i.  A bool is
    rejected explicitly because ``bool`` is a subclass of ``int`` in Python.

    Parameters
    ----------
    p : scalar
        Order of the distance.  It must be a positive finite real number.

    Returns
    -------
    float
        ``p`` converted to ``float``.

    Raises
    ------
    TypeError
        If ``p`` is not a real scalar.
    ValueError
        If ``p`` is not finite or is not strictly positive.
    """
    if isinstance(p, (bool, np.bool_)):
        raise TypeError("p must be a real scalar, not bool")
    if not np.isscalar(p):
        raise TypeError("p must be a real scalar")
    try:
        p = float(p)
    except (TypeError, ValueError) as exc:
        raise TypeError("p must be a real scalar") from exc
    if not np.isfinite(p):
        raise ValueError("p must be finite")
    if p <= 0:
        raise ValueError("p must be strictly positive")
    return p


def minkowski(u, v, p: float = 2, w=None) -> float:
    """Compute the weighted Minkowski distance between two vectors.

    The Minkowski distance of order ``p`` with weights ``w`` is

    .. math::

        d(u, v) = \\left( \\sum_{i=1}^{n} w_i |u_i - v_i|^p \\right)^{1/p},

    where ``w_i = 1`` when ``w`` is not given.

    Parameters
    ----------
    u : array_like
        First input vector, one-dimensional.
    v : array_like
        Second input vector, one-dimensional and of the same length as ``u``.
    p : float, optional
        Order of the distance, a positive finite real number.  The default
        is ``2`` (Euclidean distance).  ``p = 1`` gives the Manhattan
        distance; ``0 < p < 1`` is allowed numerically, although the result
        is then not a metric.
    w : array_like, optional
        Non-negative weights, one per coordinate.  The default ``None``
        means equal weights.  At least one weight must be positive.

    Returns
    -------
    float
        The (weighted) Minkowski distance.

    Raises
    ------
    ValueError
        If the vectors have different lengths, if a vector is not
        one-dimensional or contains NaN/Inf, if ``w`` has the wrong shape or
        contains negative/non-finite values, or if ``p <= 0``.
    TypeError
        If ``p`` is not a real scalar.

    Notes
    -----
    For ``p >= 1`` the result is a metric.  For ``0 < p < 1`` the triangle
    inequality fails in general, but the formula is still well defined and is
    used, for example, in some similarity measures.

    Examples
    --------
    The default order is ``p = 2`` (Euclidean distance):

    >>> minkowski([1, 0, 0], [0, 1, 0])
    1.4142135623730951

    ``p = 1`` gives the Manhattan (city-block) distance:

    >>> minkowski([1, 0, 0], [0, 1, 0], p=1)
    2.0

    ``p = 3`` gives the order-3 Minkowski distance:

    >>> minkowski([1, 0, 0], [0, 1, 0], p=3)
    1.2599210498948732

    Weights emphasize or de-emphasize individual coordinates:

    >>> minkowski([1, 2, 3], [3, 2, 1], p=2, w=[0.1, 0.7, 0.2])
    1.0954451150103324

    The same weighted example with ``p = 1``:

    >>> minkowski([1, 2, 3], [3, 2, 1], p=1, w=[1, 2, 3])
    8.0

    A fractional order ``0 < p < 1`` is also accepted:

    >>> minkowski([0, 1, 1, 0, 0, 1], [1, 0, 0, 1, 1, 0], p=0.5)
    36.0

    The two vectors must have the same length:

    >>> minkowski([1, 2], [1, 2, 3])
    Traceback (most recent call last):
        ...
    ValueError: u and v must have the same length
    """
    u = _validate_vector(u, "u")
    v = _validate_vector(v, "v")
    if u.size != v.size:
        raise ValueError("u and v must have the same length")
    w = _validate_weights(w, u.size)
    p = _validate_p(p)

    diff = np.abs(u - v)
    return float(np.sum(w * np.power(diff, p)) ** (1.0 / p))


if __name__ == "__main__":
    # A tiny self-check used when the file is executed directly.
    print(minkowski([1, 2, 3], [3, 2, 1], p=2, w=[0.1, 0.7, 0.2]))
```

</details>

---

## 第 2 题（20 分）MATLAB 绘制克莱因瓶

### 参数方程

克莱因瓶（Klein bottle）的参数方程为

$$
\begin{aligned}
x(u,v)&=-\frac{2}{15}\cos u\Bigl(3\cos v-30\sin u+90\cos^4 u\sin u\\
&\qquad -60\cos^6 u\sin u+5\cos u\cos v\sin u\Bigr),\\[2mm]
y(u,v)&=-\frac{1}{15}\sin u\Bigl(3\cos v-3\cos^2 u\cos v-48\cos^4 u\cos v\\
&\qquad +48\cos^6 u\cos v-60\sin u+5\cos u\cos v\sin u\\
&\qquad -5\cos^3 u\cos v\sin u-80\cos^5 u\cos v\sin u\\
&\qquad +80\cos^7 u\cos v\sin u\Bigr),\\[2mm]
z(u,v)&=\frac{2}{15}\left(3+5\cos u\sin u\right)\sin v,
\end{aligned}
$$

其中 $u\in[0,2\pi)$，$v\in[0,2\pi)$。

### MATLAB 代码

```matlab
% q2_klein_bottle.m
% Render a Klein bottle with MATLAB's surf function.
% The parametrisation is the one given in the exam question.

clear; clc; close all;

nu = 181;  nv = 181;
u = linspace(0, 2*pi, nu);
v = linspace(0, 2*pi, nv);
[U, V] = meshgrid(u, v);

X = -(2/15).*cos(U).*(3*cos(V) - 30*sin(U) ...
    + 90*cos(U).^4.*sin(U) - 60*cos(U).^6.*sin(U) ...
    + 5*cos(U).*cos(V).*sin(U));

Y = -(1/15).*sin(U).*(3*cos(V) - 3*cos(U).^2.*cos(V) ...
    - 48*cos(U).^4.*cos(V) + 48*cos(U).^6.*cos(V) ...
    - 60*sin(U) + 5*cos(U).*cos(V).*sin(U) ...
    - 5*cos(U).^3.*cos(V).*sin(U) ...
    - 80*cos(U).^5.*cos(V).*sin(U) ...
    + 80*cos(U).^7.*cos(V).*sin(U));

Z = (2/15).*(3 + 5*cos(U).*sin(U)).*sin(V);

% Use Y as colour data so that the bottle has a smooth bottom-to-top
% parula gradient; C = Z (the surf default) would also be valid.
C = Y;

fig = figure('Color', 'w', 'Position', [100 100 900 900]);
surf(X, Y, Z, C, 'EdgeColor', 'none', 'FaceColor', 'interp');
colormap(parula(256));
camlight('headlight');
lighting gouraud;
material dull;
axis equal;  axis off;  view(3);
set(gca, 'DataAspectRatio', [1 1 1]);

exportgraphics(fig, 'klein_bottle.png', 'Resolution', 300);
```

代码要点：

1. `meshgrid` 生成 $181\times181$ 的参数网格，既保证曲面光滑，又不会让 `surf` 的面片过密；
2. 所有乘、除、乘方都使用数组运算 `.*`、`./`、`.^`，这是 `surf` 能接受矩阵输入的前提；
3. `surf(X,Y,Z,C,...)` 用 `C = Y` 作为着色数据，得到自下而上的 parula 渐变；`'EdgeColor','none'` 与 `'FaceColor','interp'` 得到连续着色的曲面，`camlight` 与 `lighting gouraud` 增加立体感；
4. `axis equal` 与 `DataAspectRatio` 保证三个坐标轴等比例，瓶子不会被压扁；
5. `exportgraphics` 以 300 dpi 导出 PNG，便于插入文档。

### 渲染结果

![克莱因瓶](figs/klein_bottle.png)

> **关于本图的说明.** 本机未安装 MATLAB，因此文档中的图是用与 MATLAB 脚本完全等价的 Python 渲染脚本 `render_klein.py` 生成的（同一组参数方程、同一 `parula` 配色、同样的 `surf` 光滑着色），仅用于在提交的 PDF 中展示结果。压缩包中的 `q2_klein_bottle.m` 是可直接在 MATLAB 中运行的正式代码；运行后得到的 `klein_bottle.png` 与本图在几何上一致，视角可通过最后的 `view(...)` 一行调整。

---

## 第 3 题（20 分）Mathematica

### （i）无穷级数

需要求

$$
S=\sum_{n=1}^{\infty}(-1)^{n-1}\frac{\sin n}{n}.
$$

#### Mathematica 代码与输出

```mathematica
Sum[(-1)^(n - 1) Sin[n]/n, {n, 1, Infinity}]
(* 1/2 *)
```

Mathematica 直接给出

$$
S=\frac12.
$$

#### 推导

对 $0<x<2\pi$，有标准的 Fourier 级数

$$
\sum_{n=1}^{\infty}\frac{\sin nx}{n}=\frac{\pi-x}{2}.
$$

取 $x=\pi-1$。因为

$$
\sin(n(\pi-1))=\sin(n\pi)\cos n-\cos(n\pi)\sin n=-(-1)^n\sin n=(-1)^{n-1}\sin n,
$$

所以

$$
S=\sum_{n=1}^{\infty}\frac{\sin(n(\pi-1))}{n}=\frac{\pi-(\pi-1)}{2}=\frac12.
$$

数值上，取前 $200000$ 项：

$$
S_{200000}=0.4999984591042664,
$$

与 $1/2$ 的差约为 $1.54\times10^{-6}$，符合交错级数部分和以 $O(1/N)$ 逼近极限的估计。

### （ii）不定积分

需要求

$$
I=\int\sqrt{\tan x}\,\mathrm{d}x.
$$

#### Mathematica 代码与输出

```mathematica
integral = Integrate[Sqrt[Tan[x]], x];
FullSimplify[D[integral, x] - Sqrt[Tan[x]]]
(* 0 *)
```

Mathematica 返回一个由对数与反正切组成的结果。将其整理为实函数形式，可写成

$$
\begin{aligned}
I={}&\frac{1}{2\sqrt2}\Bigl[2\arctan\!\left(1+\sqrt2\sqrt{\tan x}\right)
+2\arctan\!\left(-1+\sqrt2\sqrt{\tan x}\right)\\
&-\ln\!\left(1+\sqrt2\sqrt{\tan x}+\tan x\right)
+\ln\!\left(1-\sqrt2\sqrt{\tan x}+\tan x\right)\Bigr]+C.
\end{aligned}
$$

#### 推导

令

$$
t=\sqrt{\tan x},\qquad \tan x=t^2,\qquad \mathrm{d}x=\frac{2t}{1+t^4}\,\mathrm{d}t.
$$

于是

$$
I=\int t\cdot\frac{2t}{1+t^4}\,\mathrm{d}t=\int\frac{2t^2}{1+t^4}\,\mathrm{d}t.
$$

分解分母：

$$
1+t^4=\left(t^2+\sqrt2\,t+1\right)\left(t^2-\sqrt2\,t+1\right).
$$

部分分式分解为

$$
\frac{2t^2}{1+t^4}
=-\frac{\sqrt2\,t}{2\left(t^2+\sqrt2\,t+1\right)}
+\frac{\sqrt2\,t}{2\left(t^2-\sqrt2\,t+1\right)}.
$$

对两项分别配方：

$$
\begin{aligned}
\int\frac{2t^2}{1+t^4}\,\mathrm{d}t
&=\frac{\sqrt2}{4}\ln\frac{t^2-\sqrt2\,t+1}{t^2+\sqrt2\,t+1}\\
&\quad+\frac{\sqrt2}{2}\left[\arctan\left(\sqrt2\,t+1\right)
+\arctan\left(\sqrt2\,t-1\right)\right]+C.
\end{aligned}
$$

代回 $t=\sqrt{\tan x}$，即得上面的结果。该式在 $\tan x>0$ 的每个区间内成立；跨过 $\tan x=0$ 的分点时，需按区间取不同的积分常数。

#### 验证

- **求导验证.** 对上式求导并化简，Mathematica 给出 `FullSimplify[D[integral, x] - Sqrt[Tan[x]]]` $\Rightarrow$ `0`。
- **数值验证.** 取三个区间，比较数值积分与公式：

| 区间 | $\int_a^b\sqrt{\tan x}\,\mathrm{d}x$ | 公式 $F(b)-F(a)$ | 误差 |
|---|---:|---:|---:|
| $[0.2,0.8]$ | 0.4424042324830764 | 0.4424042324830764 | $<10^{-15}$ |
| $[1.2,1.5]$ | 0.6801516077597236 | 0.6801516077597236 | $<10^{-15}$ |
| $[3.3,3.8]$ | 0.3261699182563226 | 0.3261699182563226 | $<10^{-15}$ |

---

## 第 4 题（30 分）排版复现：Navier–Stokes Equations

下面为题目要求的英文文本。PDF 中的对应小节由 `answers.typ` 排版生成，标题、公式与列表的显示效果与题目图片一致。

# Navier–Stokes Equations

The Navier–Stokes momentum equation can be derived as a particular form of the Cauchy momentum equation, whose general convective form is:

$$
\frac{D\mathbf{u}}{Dt}=\frac{1}{\rho}\nabla\cdot\boldsymbol{\sigma}+\mathbf{a}.
$$

By setting the Cauchy stress tensor $\boldsymbol{\sigma}$ to be the sum of a viscosity term $\boldsymbol{\tau}$ (the deviatoric stress) and a pressure term $-p\mathbf{I}$ (volumetric stress), we arrive at:

$$
\rho\frac{D\mathbf{u}}{Dt}=-\nabla p+\nabla\cdot\boldsymbol{\tau}+\rho\mathbf{a}
$$

where

- $\frac{D\mathbf{u}}{Dt}$ is the material derivative, defined as $\frac{\partial}{\partial t}+\mathbf{u}\cdot\nabla$,
- $\rho$ is the (mass) density,
- $\mathbf{u}$ is the flow velocity,
- $\nabla\cdot$ is the divergence,
- $p$ is the pressure,
- $t$ is time,
- $\tau$ is the Deviatoric stress/deviatoric stress tensor, which has order 2,
- $\mathbf{a}$ represents body forces acting on the continuum, for example gravity, Fictitious force/inertial accelerations, Coulomb’s law/electrostatic accelerations, and so on.

In this form, it is apparent that in the assumption of an inviscid fluid – no deviatoric stress – Cauchy equations reduce to the [Euler equations](https://en.wikipedia.org/wiki/Euler_equations_(fluid_dynamics)).

---

## 附录 A　答案文件清单

压缩包 `minkowski_exam_answers.zip` 中包含：

| 文件 | 说明 |
|---|---|
| `answers.pdf` | 本解答的 PDF（由 `answers.typ` 编译） |
| `answers.md` | 本解答的 Markdown 版本 |
| `answers.typ` | PDF 的 Typst 源文件 |
| `minkowski.py` | 第 1 题完整模块（含校验函数与 Examples） |
| `q1_minkowski.py` | 第 1 题第 (iii) 问的计算脚本 |
| `q1_validation_demo.py` | 第 1 题第 (i) 问的校验演示 |
| `q2_klein_bottle.m` | 第 2 题 MATLAB 代码 |
| `q3_mathematica.wl` | 第 3 题 Mathematica 代码 |
| `render_klein.py` | 生成 PDF 中克莱因瓶插图的辅助脚本 |
| `figs/klein_bottle.svg` | 克莱因瓶矢量图 |
| `figs/klein_bottle.png` | 克莱因瓶位图（300 dpi 预览） |

## 附录 B　第 1 题校验演示脚本

```python
"""Question 1, part i: validate u, v, w and p before computing a distance.

The validators ``_validate_vector`` and ``_validate_weights`` come from
``minkowski.py``; ``_validate_p`` is the additional validation function
written for this part.  Running this file prints a table of accepted and
rejected inputs.
"""

from __future__ import annotations

import numpy as np

from minkowski import _validate_p, _validate_vector, _validate_weights


def validate_inputs(u, v, p=2, w=None):
    """Validate all four parameters and return normalised values.

    Returns
    -------
    (u, v, w, p) : tuple
        ``u``, ``v`` and ``w`` as float arrays, and ``p`` as a float.
    """
    u = _validate_vector(u, "u")
    v = _validate_vector(v, "v")
    if u.size != v.size:
        raise ValueError("u and v must have the same length")
    w = _validate_weights(w, u.size)
    p = _validate_p(p)
    return u, v, w, p


def main() -> None:
    valid = [
        ([1, 2, 3], [3, 2, 1], 2, [0.1, 0.7, 0.2]),
        ([0, 1, 1, 0], [1, 0, 0, 1], 0.5, None),
        ((0.1, 0.5, -0.3), (-0.5, 1.5, 0.3), 3, [1, 1, 1]),
    ]
    invalid = [
        ([1, 2], [1, 2, 3], 2, None),          # different lengths
        ([[1, 2]], [[3, 4]], 2, None),          # not one-dimensional
        ([1, np.nan], [1, 2], 2, None),         # NaN in u
        ([1, 2], [1, 2], 2, [1]),               # wrong w length
        ([1, 2], [1, 2], 2, [1, -1]),           # negative weight
        ([1, 2], [1, 2], 2, [0, 0]),            # all weights zero
        ([1, 2], [1, 2], 0, None),              # p == 0
        ([1, 2], [1, 2], -1, None),             # p < 0
        ([1, 2], [1, 2], float("inf"), None),   # p not finite
        ([1, 2], [1, 2], True, None),           # bool is not a valid p
    ]

    print("accepted inputs")
    print("-" * 62)
    for u, v, p, w in valid:
        uu, vv, ww, pp = validate_inputs(u, v, p, w)
        print(f"u={uu}, v={vv}, p={pp}, w={ww}")

    print("\nrejected inputs")
    print("-" * 62)
    for u, v, p, w in invalid:
        try:
            validate_inputs(u, v, p, w)
        except (TypeError, ValueError) as exc:
            print(f"{type(exc).__name__}: {exc}")
        else:
            print("ERROR: invalid input was accepted")


if __name__ == "__main__":
    main()
```


