"""Question 1, part i: validate u, v, w and p before computing a distance.

The validators ``_validate_vector`` and ``_validate_weights`` come from
``minkowski.py``; ``_validate_p`` is the additional validation function
written for this part.  Running this file prints a table of accepted and
rejected inputs.
"""

from __future__ import annotations

import numpy as np

from minkowski import _validate_p, _validate_vector, _validate_weights


def validate_inputs(u, v, p=2, w=None):
    """Validate all four parameters and return normalised values.

    Returns
    -------
    (u, v, w, p) : tuple
        ``u``, ``v`` and ``w`` as float arrays, and ``p`` as a float.
    """
    u = _validate_vector(u, "u")
    v = _validate_vector(v, "v")
    if u.size != v.size:
        raise ValueError("u and v must have the same length")
    w = _validate_weights(w, u.size)
    p = _validate_p(p)
    return u, v, w, p


def main() -> None:
    valid = [
        ([1, 2, 3], [3, 2, 1], 2, [0.1, 0.7, 0.2]),
        ([0, 1, 1, 0], [1, 0, 0, 1], 0.5, None),
        ((0.1, 0.5, -0.3), (-0.5, 1.5, 0.3), 3, [1, 1, 1]),
    ]
    invalid = [
        ([1, 2], [1, 2, 3], 2, None),          # different lengths
        ([[1, 2]], [[3, 4]], 2, None),          # not one-dimensional
        ([1, np.nan], [1, 2], 2, None),         # NaN in u
        ([1, 2], [1, 2], 2, [1]),               # wrong w length
        ([1, 2], [1, 2], 2, [1, -1]),           # negative weight
        ([1, 2], [1, 2], 2, [0, 0]),            # all weights zero
        ([1, 2], [1, 2], 0, None),              # p == 0
        ([1, 2], [1, 2], -1, None),             # p < 0
        ([1, 2], [1, 2], float("inf"), None),   # p not finite
        ([1, 2], [1, 2], True, None),           # bool is not a valid p
    ]

    print("accepted inputs")
    print("-" * 62)
    for u, v, p, w in valid:
        uu, vv, ww, pp = validate_inputs(u, v, p, w)
        print(f"u={uu}, v={vv}, p={pp}, w={ww}")

    print("\nrejected inputs")
    print("-" * 62)
    for u, v, p, w in invalid:
        try:
            validate_inputs(u, v, p, w)
        except (TypeError, ValueError) as exc:
            print(f"{type(exc).__name__}: {exc}")
        else:
            print("ERROR: invalid input was accepted")


if __name__ == "__main__":
    main()
