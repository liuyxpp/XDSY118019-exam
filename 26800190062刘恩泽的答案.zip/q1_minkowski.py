"""Question 1, part iii: compute three Minkowski distances.

Run from the directory that contains ``minkowski.py``:

    python q1_minkowski.py
"""

from minkowski import minkowski


def main() -> None:
    cases = [
        ("u1, v1", [1, 2, 3], [3, 2, 1], 2, [0.1, 0.7, 0.2]),
        ("u2, v2", [0, 1, 1, 0, 0, 1], [1, 0, 0, 1, 1, 0], 0.5, None),
        ("u3, v3", [0.1, 0.5, -0.3, -1.2], [-0.5, 1.5, 0.3, 0.6], 3, None),
    ]

    for name, u, v, p, w in cases:
        d = minkowski(u, v, p=p, w=w)
        print(f"{name}: p={p!r}, w={w!r}")
        print(f"  d = {d!r}")
        print(f"  d = {d:.10f}")


if __name__ == "__main__":
    main()
