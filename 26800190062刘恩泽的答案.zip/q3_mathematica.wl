(* q3_mathematica.wl
   Question 3: an infinite series and an indefinite integral. *)

(* (i) Infinite series *)
series = Sum[(-1)^(n - 1) Sin[n]/n, {n, 1, Infinity}];
Print["S = ", series];
Print["S (numeric) = ", N[series, 30]];

(* (ii) Indefinite integral *)
integral = Integrate[Sqrt[Tan[x]], x];
Print["I = ", integral];
Print["check = ", FullSimplify[D[integral, x] - Sqrt[Tan[x]]]];

(* Numerical checks of the antiderivative on three intervals *)
f[x_] := Sqrt[Tan[x]];
Print["check [0.2,0.8] = ",
  NIntegrate[f[x], {x, 0.2, 0.8}, WorkingPrecision -> 30] -
  (integral /. x -> 0.8) + (integral /. x -> 0.2)];
Print["check [1.2,1.5] = ",
  NIntegrate[f[x], {x, 1.2, 1.5}, WorkingPrecision -> 30] -
  (integral /. x -> 1.5) + (integral /. x -> 1.2)];
Print["check [3.3,3.8] = ",
  NIntegrate[f[x], {x, 3.3, 3.8}, WorkingPrecision -> 30] -
  (integral /. x -> 3.8) + (integral /. x -> 3.3)];
