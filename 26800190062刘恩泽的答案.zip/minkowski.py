"""Minkowski distance with input validation.

This module accompanies Question 1 of the exam.  The public function is
:func:`minkowski`; the three private helpers are the validation functions
used by the answer:

* ``_validate_vector``  -- validate one vector (used for ``u`` and ``v``);
* ``_validate_weights`` -- validate the weight vector ``w``;
* ``_validate_p``       -- validate the order ``p`` (written for part i).

Run ``python -m doctest minkowski.py -v`` to execute all examples in the
docstring.
"""

from __future__ import annotations

import numpy as np


def _validate_vector(x, name: str = "x") -> np.ndarray:
    """Return ``x`` as a finite one-dimensional float array.

    Parameters
    ----------
    x : array_like
        Vector to validate.
    name : str, optional
        Name used in error messages.

    Returns
    -------
    numpy.ndarray
        A one-dimensional ``float64`` array.

    Raises
    ------
    ValueError
        If ``x`` is not one-dimensional, is empty, or contains NaN/Inf.
    """
    a = np.asarray(x, dtype=float)
    if a.ndim != 1:
        raise ValueError(f"{name} must be a one-dimensional array")
    if a.size == 0:
        raise ValueError(f"{name} must not be empty")
    if not np.all(np.isfinite(a)):
        raise ValueError(f"{name} must contain only finite values")
    return a


def _validate_weights(w, n: int) -> np.ndarray:
    """Validate the weight vector and expand ``None`` to all ones.

    Parameters
    ----------
    w : array_like or None
        Non-negative weights.  ``None`` means equal weights.
    n : int
        Required number of weights.

    Returns
    -------
    numpy.ndarray
        A one-dimensional ``float64`` array of length ``n``.

    Raises
    ------
    ValueError
        If ``w`` has the wrong shape, contains NaN/Inf or negative values,
        or is the all-zero vector.
    """
    if w is None:
        return np.ones(n, dtype=float)

    a = np.asarray(w, dtype=float)
    if a.ndim != 1:
        raise ValueError("w must be a one-dimensional array")
    if a.size != n:
        raise ValueError(f"w must have length {n}, got {a.size}")
    if not np.all(np.isfinite(a)):
        raise ValueError("w must contain only finite values")
    if np.any(a < 0):
        raise ValueError("w must be non-negative")
    if not np.any(a > 0):
        raise ValueError("w must contain at least one positive weight")
    return a


def _validate_p(p) -> float:
    """Validate the order ``p`` of the Minkowski distance.

    This is the validation code written by hand for part i.  A bool is
    rejected explicitly because ``bool`` is a subclass of ``int`` in Python.

    Parameters
    ----------
    p : scalar
        Order of the distance.  It must be a positive finite real number.

    Returns
    -------
    float
        ``p`` converted to ``float``.

    Raises
    ------
    TypeError
        If ``p`` is not a real scalar.
    ValueError
        If ``p`` is not finite or is not strictly positive.
    """
    if isinstance(p, (bool, np.bool_)):
        raise TypeError("p must be a real scalar, not bool")
    if not np.isscalar(p):
        raise TypeError("p must be a real scalar")
    try:
        p = float(p)
    except (TypeError, ValueError) as exc:
        raise TypeError("p must be a real scalar") from exc
    if not np.isfinite(p):
        raise ValueError("p must be finite")
    if p <= 0:
        raise ValueError("p must be strictly positive")
    return p


def minkowski(u, v, p: float = 2, w=None) -> float:
    """Compute the weighted Minkowski distance between two vectors.

    The Minkowski distance of order ``p`` with weights ``w`` is

    .. math::

        d(u, v) = \\left( \\sum_{i=1}^{n} w_i |u_i - v_i|^p \\right)^{1/p},

    where ``w_i = 1`` when ``w`` is not given.

    Parameters
    ----------
    u : array_like
        First input vector, one-dimensional.
    v : array_like
        Second input vector, one-dimensional and of the same length as ``u``.
    p : float, optional
        Order of the distance, a positive finite real number.  The default
        is ``2`` (Euclidean distance).  ``p = 1`` gives the Manhattan
        distance; ``0 < p < 1`` is allowed numerically, although the result
        is then not a metric.
    w : array_like, optional
        Non-negative weights, one per coordinate.  The default ``None``
        means equal weights.  At least one weight must be positive.

    Returns
    -------
    float
        The (weighted) Minkowski distance.

    Raises
    ------
    ValueError
        If the vectors have different lengths, if a vector is not
        one-dimensional or contains NaN/Inf, if ``w`` has the wrong shape or
        contains negative/non-finite values, or if ``p <= 0``.
    TypeError
        If ``p`` is not a real scalar.

    Notes
    -----
    For ``p >= 1`` the result is a metric.  For ``0 < p < 1`` the triangle
    inequality fails in general, but the formula is still well defined and is
    used, for example, in some similarity measures.

    Examples
    --------
    The default order is ``p = 2`` (Euclidean distance):

    >>> minkowski([1, 0, 0], [0, 1, 0])
    1.4142135623730951

    ``p = 1`` gives the Manhattan (city-block) distance:

    >>> minkowski([1, 0, 0], [0, 1, 0], p=1)
    2.0

    ``p = 3`` gives the order-3 Minkowski distance:

    >>> minkowski([1, 0, 0], [0, 1, 0], p=3)
    1.2599210498948732

    Weights emphasize or de-emphasize individual coordinates:

    >>> minkowski([1, 2, 3], [3, 2, 1], p=2, w=[0.1, 0.7, 0.2])
    1.0954451150103324

    The same weighted example with ``p = 1``:

    >>> minkowski([1, 2, 3], [3, 2, 1], p=1, w=[1, 2, 3])
    8.0

    A fractional order ``0 < p < 1`` is also accepted:

    >>> minkowski([0, 1, 1, 0, 0, 1], [1, 0, 0, 1, 1, 0], p=0.5)
    36.0

    The two vectors must have the same length:

    >>> minkowski([1, 2], [1, 2, 3])
    Traceback (most recent call last):
        ...
    ValueError: u and v must have the same length
    """
    u = _validate_vector(u, "u")
    v = _validate_vector(v, "v")
    if u.size != v.size:
        raise ValueError("u and v must have the same length")
    w = _validate_weights(w, u.size)
    p = _validate_p(p)

    diff = np.abs(u - v)
    return float(np.sum(w * np.power(diff, p)) ** (1.0 / p))


if __name__ == "__main__":
    # A tiny self-check used when the file is executed directly.
    print(minkowski([1, 2, 3], [3, 2, 1], p=2, w=[0.1, 0.7, 0.2]))
