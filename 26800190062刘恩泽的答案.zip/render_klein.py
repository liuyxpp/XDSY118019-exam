"""Render the Klein bottle of Question 2 to a vector SVG file.

This script is a reference renderer used to preview, without MATLAB, the
surface that ``q2_klein_bottle.m`` draws with ``surf``.  It deliberately uses
the same parametrisation and a MATLAB-like parula colour map.
"""

from __future__ import annotations

import math

import numpy as np


# --------------------------------------------------------------------------
# Parametrisation (exactly the one given in the question)
# --------------------------------------------------------------------------
def klein_surface(nu: int = 181, nv: int = 181):
    u = np.linspace(0.0, 2.0 * math.pi, nu)
    v = np.linspace(0.0, 2.0 * math.pi, nv)
    U, V = np.meshgrid(u, v, indexing="ij")

    X = -(2.0 / 15.0) * np.cos(U) * (
        3.0 * np.cos(V)
        - 30.0 * np.sin(U)
        + 90.0 * np.cos(U) ** 4 * np.sin(U)
        - 60.0 * np.cos(U) ** 6 * np.sin(U)
        + 5.0 * np.cos(U) * np.cos(V) * np.sin(U)
    )
    Y = -(1.0 / 15.0) * np.sin(U) * (
        3.0 * np.cos(V)
        - 3.0 * np.cos(U) ** 2 * np.cos(V)
        - 48.0 * np.cos(U) ** 4 * np.cos(V)
        + 48.0 * np.cos(U) ** 6 * np.cos(V)
        - 60.0 * np.sin(U)
        + 5.0 * np.cos(U) * np.cos(V) * np.sin(U)
        - 5.0 * np.cos(U) ** 3 * np.cos(V) * np.sin(U)
        - 80.0 * np.cos(U) ** 5 * np.cos(V) * np.sin(U)
        + 80.0 * np.cos(U) ** 7 * np.cos(V) * np.sin(U)
    )
    Z = (2.0 / 15.0) * (3.0 + 5.0 * np.cos(U) * np.sin(U)) * np.sin(V)
    return U, V, X, Y, Z


# --------------------------------------------------------------------------
# parula colour map (MATLAB's default), sampled from its anchor points
# --------------------------------------------------------------------------
_PARULA = np.array(
    [
        [0.2422, 0.1504, 0.6603],
        [0.2810, 0.3228, 0.9573],
        [0.1786, 0.5289, 0.9682],
        [0.0689, 0.6948, 0.8394],
        [0.2161, 0.7843, 0.5923],
        [0.5442, 0.8068, 0.3824],
        [0.8721, 0.7471, 0.1969],
        [0.9830, 0.5965, 0.1601],
        [0.9769, 0.9839, 0.0805],
    ]
)


def parula(t: np.ndarray) -> np.ndarray:
    t = np.clip(t, 0.0, 1.0)
    x = t * (len(_PARULA) - 1)
    i = np.minimum(np.floor(x).astype(int), len(_PARULA) - 2)
    f = (x - i)[:, None]
    return _PARULA[i] * (1.0 - f) + _PARULA[i + 1] * f


# --------------------------------------------------------------------------
# Rendering
# --------------------------------------------------------------------------
def render(
    out_svg: str,
    *,
    azim_deg: float = 24.0,
    elev_deg: float = 12.0,
    width: int = 1500,
    height: int = 1500,
    color_mode: str = "y",
) -> None:
    U, V, X, Y, Z = klein_surface(181, 181)

    # Centre the bottle.  Its long axis is +y, so we put the centre of the
    # bounding box at the origin.
    pts = np.stack([X, Y, Z], axis=-1)
    lo = pts.reshape(-1, 3).min(axis=0)
    hi = pts.reshape(-1, 3).max(axis=0)
    pts = pts - 0.5 * (lo + hi)

    az, el = math.radians(azim_deg), math.radians(elev_deg)
    cz, sz = math.cos(az), math.sin(az)
    ce, se = math.cos(el), math.sin(el)
    rz = np.array([[cz, sz, 0.0], [-sz, cz, 0.0], [0.0, 0.0, 1.0]])
    rx = np.array([[1.0, 0.0, 0.0], [0.0, ce, se], [0.0, -se, ce]])
    q = pts @ rz.T @ rx.T

    # Project (orthographic, as MATLAB's default camproj).
    x2, y2, depth = q[..., 0], q[..., 1], q[..., 2]
    span_x = x2.max() - x2.min()
    span_y = y2.max() - y2.min()
    scale = 0.88 * min(width / span_x, height / span_y)
    cx, cy = width / 2.0, height / 2.0
    sx = cx + scale * x2
    sy = cy - scale * y2
    zmin, zmax = depth.min(), depth.max()

    # Face colours
    if color_mode == "z":
        cval = 0.25 * Z + 0.75 * Y
    elif color_mode == "u":
        cval = U / (2.0 * math.pi)
    else:
        cval = Y
    t = (cval - cval.min()) / (cval.max() - cval.min())
    base = parula(t.reshape(-1)).reshape(cval.shape + (3,))

    # Lambert shading with a light from the upper left front.
    light = np.array([-0.35, 0.55, 0.75])
    light = light / np.linalg.norm(light)
    du = q[1:, :-1] - q[:-1, :-1]
    dv = q[:-1, 1:] - q[:-1, :-1]
    n = np.cross(du, dv)
    n = n / (np.linalg.norm(n, axis=-1, keepdims=True) + 1e-12)
    lam = np.abs(n @ light)
    shade = 0.45 + 0.55 * lam

    # Depth cue: very slight fade to white for the far side.
    fog = 0.90 + 0.10 * (depth[:-1, :-1] - zmin) / (zmax - zmin + 1e-12)
    rgb = np.clip(base[:-1, :-1] * shade[..., None] * fog[..., None], 0.0, 1.0)

    # Painter's algorithm: far faces first (camera looks along +z).
    face_depth = 0.25 * (
        depth[:-1, :-1] + depth[1:, :-1] + depth[1:, 1:] + depth[:-1, 1:]
    ).reshape(-1)
    order = np.argsort(face_depth)

    p00 = np.stack([sx[:-1, :-1], sy[:-1, :-1]], axis=-1).reshape(-1, 2)
    p10 = np.stack([sx[1:, :-1], sy[1:, :-1]], axis=-1).reshape(-1, 2)
    p11 = np.stack([sx[1:, 1:], sy[1:, 1:]], axis=-1).reshape(-1, 2)
    p01 = np.stack([sx[:-1, 1:], sy[:-1, 1:]], axis=-1).reshape(-1, 2)

    lines = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" '
        f'height="{height}" viewBox="0 0 {width} {height}">',
        '<rect width="100%" height="100%" fill="#ffffff"/>',
        '<g stroke-linejoin="round" stroke-linecap="round">',
    ]
    for k in order:
        r, g, b = (int(round(255 * c)) for c in rgb.reshape(-1, 3)[k])
        colour = f"#{r:02x}{g:02x}{b:02x}"
        a = p00[k]
        bb = p10[k]
        c = p11[k]
        d = p01[k]
        lines.append(
            f'<path d="M{a[0]:.1f},{a[1]:.1f}L{bb[0]:.1f},{bb[1]:.1f}'
            f'L{c[0]:.1f},{c[1]:.1f}L{d[0]:.1f},{d[1]:.1f}Z" '
            f'fill="{colour}" stroke="{colour}" stroke-width="0.45"/>'
        )
    lines.append("</g></svg>")

    with open(out_svg, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines))


if __name__ == "__main__":
    import argparse

    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="figs/klein_bottle.svg")
    ap.add_argument("--azim", type=float, default=24.0)
    ap.add_argument("--elev", type=float, default=12.0)
    ap.add_argument("--color", choices=["y", "z", "u"], default="y")
    args = ap.parse_args()
    render(args.out, azim_deg=args.azim, elev_deg=args.elev, color_mode=args.color)
    print("written", args.out)
