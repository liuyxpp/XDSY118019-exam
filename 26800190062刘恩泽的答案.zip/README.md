# 数学实验试题解答（第 1–4 题）

本解答完成第 1–4 题：第 1–3 题为计算与作图题，第 4 题为 Navier–Stokes 方程文本的排版复现。

## 文件说明

| 文件 | 说明 |
|---|---|
| `answers.pdf` | 完整解答 PDF |
| `answers.md` | 完整解答 Markdown 版 |
| `answers.typ` | PDF 的 Typst 源文件（末尾为第 4 题排版） |
| `minkowski.py` | 第 1 题模块：加权 Minkowski 距离、校验函数、docstring Examples |
| `q1_minkowski.py` | 第 1 题第 (iii) 问的计算脚本 |
| `q1_validation_demo.py` | 第 1 题第 (i) 问的校验演示 |
| `q2_klein_bottle.m` | 第 2 题 MATLAB `surf` 代码 |
| `q3_mathematica.wl` | 第 3 题 Mathematica 代码 |
| `render_klein.py` | 生成 PDF 中克莱因瓶插图的辅助 Python 脚本 |
| `figs/klein_bottle.svg` | 克莱因瓶矢量图 |
| `figs/klein_bottle.png` | 克莱因瓶 300 dpi 位图 |
| `requirements.txt` | Python 依赖（仅 numpy） |

## 运行方法

### 第 1 题

```bash
python -m pip install -r requirements.txt
python -m doctest minkowski.py -v
python q1_validation_demo.py
python q1_minkowski.py
```

预期输出见 `answers.md` 第 1 题第 (iii) 问。

### 第 2 题

在 MATLAB 中运行：

```matlab
q2_klein_bottle
```

脚本会生成 `klein_bottle.png`。如果缺少 MATLAB，可运行辅助脚本预览同一曲面：

```bash
python render_klein.py --out figs/klein_bottle.svg --azim 320 --elev 22 --color y
```

### 第 3 题

在 Mathematica 中运行：

```mathematica
<< "q3_mathematica.wl"
```

## 重新编译 PDF

`answers.pdf` 由 Typst 0.15 编译：

```bash
typst compile --font-path "C:\Windows\Fonts" answers.typ answers.pdf
```

中文字体使用 Microsoft YaHei；若在其它系统编译，请把 `answers.typ` 中的字体名替换为本机可用的中文字体，并相应调整 `--font-path`。
