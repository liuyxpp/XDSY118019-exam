---
header-includes:
  - \usepackage{graphicx}
---

# 2026 期末考试答卷

- 学号：23307110334
- 姓名：叶尔达那

## 第 1 题：Python 编程



### 完整代码

```python
import math
import numbers
import numpy as np
from numpy.linalg import norm


def _validate_vector(u, dtype=None):
    u = np.asarray(u, dtype=dtype, order="c")
    if u.ndim == 1:
        return u
    raise ValueError("Input vector should be 1-D.")


def _validate_weights(w, dtype=np.float64):
    w = _validate_vector(w, dtype=dtype)
    if np.any(w < 0):
        raise ValueError("Input weights should be all non-negative")
    return w


def _validate_p(p):
    if isinstance(p, (bool, np.bool_)) or not isinstance(p, numbers.Real):
        raise ValueError("p must be a positive real scalar.")

    p = float(p)
    if math.isnan(p) or p <= 0:
        raise ValueError("p must be greater than 0.")

    return p


def minkowski(u, v, p=2, w=None):
    """
    Compute the Minkowski distance between two 1-D arrays.

    The Minkowski distance between 1-D arrays `u` and `v`,
    is defined as

    .. math::

       {\\|u-v\\|}_p = (\\sum{|u_i - v_i|^p})^{1/p}.


       \\left(\\sum{w_i(|(u_i - v_i)|^p)}\\right)^{1/p}.

    Parameters
    ----------
    u : (N,) array_like
        Input array.
    v : (N,) array_like
        Input array.
    p : scalar
        The order of the norm of the difference :math:`{\\|u-v\\|}_p`. Note
        that for :math:`0 < p < 1`, the triangle inequality only holds with
        an additional multiplicative factor, i.e. it is only a quasi-metric.
    w : (N,) array_like, optional
        The weights for each value in `u` and `v`. Default is None,
        which gives each value a weight of 1.0

    Returns
    -------
    minkowski : double
        The Minkowski distance between vectors `u` and `v`.

    Examples
    --------
    >>> float(minkowski([1, 0, 0], [0, 1, 0], 1))
    2.0
    >>> round(float(minkowski([0, 0], [3, 4], 2)), 4)
    5.0
    >>> float(minkowski([1, 2], [3, 4], np.inf))
    2.0
    >>> round(float(minkowski([1, 2], [3, 4], 2, [2, 0.5])), 4)
    3.1623
    >>> round(float(minkowski([1, 2, 3], [4, 6, 3], 3)), 4)
    4.4979
    """
    p = _validate_p(p)
    u = _validate_vector(u, dtype=np.float64)
    v = _validate_vector(v, dtype=np.float64)

    if u.shape != v.shape:
        raise ValueError("u and v must have the same shape.")

    if w is not None:
        w = _validate_weights(w, dtype=np.float64)
        if w.shape != u.shape:
            raise ValueError("u, v and w must have the same shape.")

    u_v = u - v
    if w is not None:
        if p == 1:
            root_w = w
        elif p == 2:
            root_w = np.sqrt(w)
        elif p == np.inf:
            root_w = w != 0
        else:
            root_w = np.power(w, 1 / p)
        u_v = root_w * u_v

    return norm(u_v, ord=p)


if __name__ == "__main__":
    cases = [
        (
            "u1-v1",
            [1, 2, 3],
            [3, 2, 1],
            2,
            [0.1, 0.7, 0.2],
        ),
        (
            "u2-v2",
            [0, 1, 1, 0, 0, 1],
            [1, 0, 0, 1, 1, 0],
            0.5,
            None,
        ),
        (
            "u3-v3",
            [0.1, 0.5, -0.3, -1.2],
            [-0.5, 1.5, 0.3, 0.6],
            3,
            None,
        ),
    ]

    for name, u, v, p, w in cases:
        distance = minkowski(u, v, p, w)
        print(f"{name}: p={p}, w={w}, distance={distance:.15g}")
```

### 运行结果

```text
u1-v1: p=2, w=[0.1, 0.7, 0.2], distance=1.09544511501033
u2-v2: p=0.5, w=None, distance=36
u3-v3: p=3, w=None, distance=1.9366833186578
```

也就是：

$$
d(\mathbf{u}_1,\mathbf{v}_1)=1.09544511501033,
\qquad
d(\mathbf{u}_2,\mathbf{v}_2)=36,
\qquad
d(\mathbf{u}_3,\mathbf{v}_3)=1.9366833186578.
$$

## 第 2 题：MATLAB 绘制克莱因瓶


### 完整代码

```matlab
% Plot the Klein bottle defined by the final-exam parameterization.

clear;
clc;
close all;

% Use a closed parameter interval [0, 2*pi).
Nu = 320;
Nv = 160;
u = 2 * pi * (0:Nu-1) / Nu;
v = 2 * pi * (0:Nv-1) / Nv;
[U, V] = meshgrid(u, v);

CU = cos(U);
SU = sin(U);
CV = cos(V);

X = -(2/15) * CU .* ( ...
    3*CV - 30*SU + 90*CU.^4.*SU - 60*CU.^6.*SU + ...
    5*CU.*CV.*SU);

Y = -(1/15) * SU .* ( ...
    3*CV - 3*CU.^2.*CV - 48*CU.^4.*CV + 48*CU.^6.*CV - ...
    60*SU + 5*CU.*CV.*SU - 5*CU.^3.*CV.*SU - ...
    80*CU.^5.*CV.*SU + 80*CU.^7.*CV.*SU);

Z = (2/15) * (3 + 5*CU.*SU) .* sin(V);

% Keep the output inside the submission directory even when this script
% is run from MATLAB's editor or with -batch.
scriptDir = fileparts(mfilename('fullpath'));
submissionDir = fileparts(scriptDir);
outputDir = fullfile(submissionDir, 'figures');
if ~exist(outputDir, 'dir')
    mkdir(outputDir);
end

figure('Color', 'w');
surf(X, Y, Z, 'EdgeColor', 'none');
axis equal;
axis tight;
grid on;
box on;
xlabel('x');
ylabel('y');
zlabel('z');
title('Klein Bottle');
view(35, 25);
colormap(turbo);
lighting gouraud;
camlight headlight;
material dull;

exportgraphics(gcf, fullfile(outputDir, 'problem2.png'), ...
    'Resolution', 300);

disp('Saved figures/problem2.png');
```

### 运行结果

```text
Saved figures/problem2.png
```

\begin{center}
\includegraphics[width=0.86\textwidth]{figures/problem2.png}
\end{center}

图：使用 MATLAB `surf` 绘制的克莱因瓶。

图中的曲面完整闭合，`axis equal` 保证三个坐标轴使用相同比例。

## 第三题：Mathematica 计算

### i

```text
In[1]:= seriesResult = Sum[(-1)^(n + 1) Sin[n]/n, {n, 1, Infinity}]

Out[1]= 1/2 i (-Log[1 + e^i] + Log[(1 + e^i) e^-i])

In[2]:= FullSimplify[seriesResult]

Out[2]= 1/2
```

### ii

```text
In[3]:= integralResult = Integrate[Sqrt[Tan[x]], x]

Out[3]= (-1)^(3/4) *
  (ArcTan[(-1)^(3/4) Sqrt[Tan[x]]] -
   ArcTanh[(-1)^(3/4) Sqrt[Tan[x]]])

In[4]:= D[integralResult, x] // Simplify

Out[4]= Sqrt[Tan[x]]
```

## 第四题：文本排版

# Navier–Stokes Equations

The Navier–Stokes momentum equation can be derived as a particular form of the Cauchy momentum equation, whose general convective form is:

$$
\frac{\mathrm{D}\mathbf{u}}{\mathrm{D}t}
=
\frac{1}{\rho}\nabla\cdot\boldsymbol{\sigma}+\mathbf{a}.
$$

By setting the Cauchy stress tensor $\boldsymbol{\sigma}$ to be the sum of a viscosity term $\boldsymbol{\tau}$ (the deviatoric stress) and a pressure term $-p\mathbf{I}$ (volumetric stress), we arrive at:

$$
\rho\frac{\mathrm{D}\mathbf{u}}{\mathrm{D}t}
=
-\nabla p+\nabla\cdot\boldsymbol{\tau}+\rho\mathbf{a},
$$

where

- $\frac{\mathrm{D}}{\mathrm{D}t}$ is the material derivative, defined as
  $\frac{\partial}{\partial t}+\mathbf{u}\cdot\nabla$,
- $\rho$ is the (mass) density,
- $\mathbf{u}$ is the flow velocity,
- $\nabla\cdot$ is the divergence,
- $p$ is the pressure,
- $t$ is time,
- $\boldsymbol{\tau}$ is the Deviatoric stress|deviatoric stress tensor, which has order 2,
- $\mathbf{a}$ represents body forces acting on the continuum, for example gravity, Fictitious force|inertial accelerations, Coulomb's law|electrostatic accelerations, and so on.

In this form, it is apparent that in the assumption of an inviscid fluid – no deviatoric stress – Cauchy equations reduce to the Euler equations.



