% Plot the Klein bottle defined by the final-exam parameterization.

clear;
clc;
close all;

% Use a closed parameter interval [0, 2*pi).
Nu = 320;
Nv = 160;
u = 2 * pi * (0:Nu-1) / Nu;
v = 2 * pi * (0:Nv-1) / Nv;
[U, V] = meshgrid(u, v);

CU = cos(U);
SU = sin(U);
CV = cos(V);

X = -(2/15) * CU .* ( ...
    3*CV - 30*SU + 90*CU.^4.*SU - 60*CU.^6.*SU + ...
    5*CU.*CV.*SU);

Y = -(1/15) * SU .* ( ...
    3*CV - 3*CU.^2.*CV - 48*CU.^4.*CV + 48*CU.^6.*CV - ...
    60*SU + 5*CU.*CV.*SU - 5*CU.^3.*CV.*SU - ...
    80*CU.^5.*CV.*SU + 80*CU.^7.*CV.*SU);

Z = (2/15) * (3 + 5*CU.*SU) .* sin(V);

% Keep the output inside the submission directory even when this script
% is run from MATLAB's editor or with -batch.
scriptDir = fileparts(mfilename('fullpath'));
submissionDir = fileparts(scriptDir);
outputDir = fullfile(submissionDir, 'figures');
if ~exist(outputDir, 'dir')
    mkdir(outputDir);
end

figure('Color', 'w');
surf(X, Y, Z, 'EdgeColor', 'none');
axis equal;
axis tight;
grid on;
box on;
xlabel('x');
ylabel('y');
zlabel('z');
title('Klein Bottle');
view(35, 25);
colormap(turbo);
lighting gouraud;
camlight headlight;
material dull;

exportgraphics(gcf, fullfile(outputDir, 'problem2.png'), ...
    'Resolution', 300);

disp('Saved figures/problem2.png');
