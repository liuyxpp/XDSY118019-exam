import math
import numbers
import numpy as np
from numpy.linalg import norm

def _validate_vector(u, dtype=None):
    u = np.asarray(u, dtype=dtype, order='c')
    if u.ndim == 1:
        return u
    raise ValueError("Input vector should be 1-D.")


def _validate_weights(w, dtype=np.float64):
    w = _validate_vector(w, dtype=dtype)
    if np.any(w < 0):
        raise ValueError("Input weights should be all non-negative")
    return w

def _validate_p(p):
    if isinstance(p, (bool, np.bool_)) or not isinstance(p, numbers.Real):
        raise ValueError("p must be a positive real scalar.")

    p = float(p)
    if math.isnan(p) or p <= 0:
        raise ValueError("p must be greater than 0.")

    return p


def minkowski(u, v, p=2, w=None):
    """
    Compute the Minkowski distance between two 1-D arrays.

    The Minkowski distance between 1-D arrays `u` and `v`,
    is defined as

    .. math::

       {\\|u-v\\|}_p = (\\sum{|u_i - v_i|^p})^{1/p}.


       \\left(\\sum{w_i(|(u_i - v_i)|^p)}\\right)^{1/p}.

    Parameters
    ----------
    u : (N,) array_like
        Input array.
    v : (N,) array_like
        Input array.
    p : scalar
        The order of the norm of the difference :math:`{\\|u-v\\|}_p`. Note
        that for :math:`0 < p < 1`, the triangle inequality only holds with
        an additional multiplicative factor, i.e. it is only a quasi-metric.
    w : (N,) array_like, optional
        The weights for each value in `u` and `v`. Default is None,
        which gives each value a weight of 1.0

    Returns
    -------
    minkowski : double
        The Minkowski distance between vectors `u` and `v`.

    Examples
    --------
    >>> float(minkowski([1, 0, 0], [0, 1, 0], 1))
    2.0
    >>> round(float(minkowski([0, 0], [3, 4], 2)), 4)
    5.0
    >>> float(minkowski([1, 2], [3, 4], np.inf))
    2.0
    >>> round(float(minkowski([1, 2], [3, 4], 2, [2, 0.5])), 4)
    3.1623
    >>> round(float(minkowski([1, 2, 3], [4, 6, 3], 3)), 4)
    4.4979
    """
    p = _validate_p(p)
    u = _validate_vector(u, dtype=np.float64)
    v = _validate_vector(v, dtype=np.float64)

    if u.shape != v.shape:
        raise ValueError("u and v must have the same shape.")

    if w is not None:
        w = _validate_weights(w, dtype=np.float64)
        if w.shape != u.shape:
            raise ValueError("u, v and w must have the same shape.")
    u_v = u - v
    if w is not None:
        if p == 1:
            root_w = w
        elif p == 2:
            # better precision and speed
            root_w = np.sqrt(w)
        elif p == np.inf:
            root_w = (w != 0)
        else:
            root_w = np.power(w, 1/p)
        u_v = root_w * u_v
    dist = norm(u_v, ord=p)
    return dist


if __name__ == '__main__':
    cases = [
        (
            "u1-v1",
            [1, 2, 3],
            [3, 2, 1],
            2,
            [0.1, 0.7, 0.2],
        ),
        (
            "u2-v2",
            [0, 1, 1, 0, 0, 1],
            [1, 0, 0, 1, 1, 0],
            0.5,
            None,
        ),
        (
            "u3-v3",
            [0.1, 0.5, -0.3, -1.2],
            [-0.5, 1.5, 0.3, 0.6],
            3,
            None,
        ),
    ]

    for name, u, v, p, w in cases:
        distance = minkowski(u, v, p, w)
        print(f"{name}: p={p}, w={w}, distance={distance:.15g}")
