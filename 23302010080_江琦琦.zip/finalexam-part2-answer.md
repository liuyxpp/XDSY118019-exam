---
title: "期末考试第二部分作答"
lang: zh-CN
---

# 1. Minkowski 距离

`u` 和 `v` 使用题给的 `_validate_vector` 校验为一维向量，再检查两者等长。`w` 使用题给的 `_validate_weights` 校验，且必须与向量等长、元素有限。`p` 接受正实数和正无穷。正无穷情形取权重非零坐标的最大绝对差。

```python
from numbers import Real

import numpy as np
from scipy.linalg import norm

def _validate_vector(u, dtype=None):
    u = np.asarray(u, dtype=dtype, order='c')
    if u.ndim == 1:
        return u
    raise ValueError("Input vector should be 1-D.")


def _validate_weights(w, dtype=np.float64):
    w = _validate_vector(w, dtype=dtype)
    if np.any(w < 0):
        raise ValueError("Input weights should be all non-negative")
    return w


def minkowski(u, v, p=2, w=None):
    """
    Compute the Minkowski distance between two 1-D arrays.

    The Minkowski distance between 1-D arrays `u` and `v`,
    is defined as

    .. math::

       {\\|u-v\\|}_p = (\\sum{|u_i - v_i|^p})^{1/p}.


       \\left(\\sum{w_i(|(u_i - v_i)|^p)}\\right)^{1/p}.

    Parameters
    ----------
    u : (N,) array_like
        Input array.
    v : (N,) array_like
        Input array.
    p : scalar
        The order of the norm of the difference :math:`{\\|u-v\\|}_p`. Note
        that for :math:`0 < p < 1`, the triangle inequality only holds with
        an additional multiplicative factor, i.e. it is only a quasi-metric.
    w : (N,) array_like, optional
        The weights for each value in `u` and `v`. Default is None,
        which gives each value a weight of 1.0

    Returns
    -------
    minkowski : double
        The Minkowski distance between vectors `u` and `v`.

    Examples
    --------
    >>> float(minkowski([1, 0, 0], [0, 1, 0], p=1))
    2.0
    >>> float(minkowski([0, 0], [3, 4]))
    5.0
    >>> float(minkowski([0, 0], [3, 4], p=np.inf))
    4.0
    >>> float(minkowski([1, 2], [3, 5], p=1, w=[2, 1]))
    7.0
    >>> float(minkowski([0, 0], [2, 3], p=2, w=[4, 0]))
    4.0
    >>> round(float(minkowski([0, 0], [1, 1], p=0.5)), 12)
    4.0
    """
    u = _validate_vector(u)
    v = _validate_vector(v)
    if u.shape != v.shape:
        raise ValueError("Input vectors must have the same length.")
    if isinstance(p, (bool, np.bool_)) or not isinstance(p, Real) or not p > 0:
        raise ValueError("p must be a positive real number or positive infinity.")

    # Promote integer inputs before subtracting to avoid fixed-width overflow.
    dtype = np.result_type(u.dtype, v.dtype, np.float64)
    u_v = u.astype(dtype, copy=False) - v.astype(dtype, copy=False)
    if w is not None:
        w = _validate_weights(w)
        if w.shape != u.shape:
            raise ValueError("Weights must have the same length as the input vectors.")
        if not np.all(np.isfinite(w)):
            raise ValueError("Weights must be finite.")
        if p == 1:
            root_w = w
        elif p == 2:
            # better precision and speed
            root_w = np.sqrt(w)
        elif p == np.inf:
            root_w = (w != 0)
        else:
            root_w = np.power(w, 1/p)
        u_v = root_w * u_v
    dist = norm(u_v, ord=p)
    return dist


if __name__ == '__main__':
    cases = [
        ([1, 2, 3], [3, 2, 1], 2, [0.1, 0.7, 0.2]),
        ([0, 1, 1, 0, 0, 1], [1, 0, 0, 1, 1, 0], 0.5, None),
        ([0.1, 0.5, -0.3, -1.2], [-0.5, 1.5, 0.3, 0.6], 3, None),
    ]
    for index, (u, v, p, w) in enumerate(cases, start=1):
        print(f"d{index} = {minkowski(u, v, p, w):.12f}")
```

三组向量的计算结果如下。

| 向量对 | 距离的精确值 | 数值 |
|:--|:--|--:|
| 1 | $\sqrt{1.2}$ | 1.095445115010 |
| 2 | $36$ | 36.000000000000 |
| 3 | $\sqrt[3]{7.264}$ | 1.936683318658 |

<div class="page-break"></div>

# 2. MATLAB 绘制克莱因瓶

使用题给的参数方程构造曲面网格，并在采样时纳入周期端点以闭合曲面。颜色随 $z$ 变化。

```matlab
u = linspace(0, 2*pi, 241);
v = linspace(0, 2*pi, 181);
[U, V] = meshgrid(u, v);
cu = cos(U);
su = sin(U);
cv = cos(V);

X = -(2/15).*cu.*(3*cv - 30*su + 90*cu.^4.*su ...
    - 60*cu.^6.*su + 5*cu.*cv.*su);
Y = -(1/15).*su.*(3*cv - 3*cu.^2.*cv - 48*cu.^4.*cv ...
    + 48*cu.^6.*cv - 60*su + 5*cu.*cv.*su - 5*cu.^3.*cv.*su ...
    - 80*cu.^5.*cv.*su + 80*cu.^7.*cv.*su);
Z = (2/15).*(3 + 5*cu.*su).*sin(V);

fig = figure('Visible', 'off', 'Color', 'w', 'Position', [100 100 860 620]);
surf(X, Y, Z, Z, 'EdgeColor', 'none');
axis equal tight
xlabel('x'); ylabel('y'); zlabel('z');
title('Klein bottle');
view(38, 24);
colormap(parula);
camlight('headlight');
lighting gouraud
exportgraphics(fig, 'klein-bottle.png', 'Resolution', 180);
```

![MATLAB surf 渲染的克莱因瓶](klein-bottle.png){ width=83% }

<div class="page-break"></div>

# 3. Mathematica 级数与积分

## i. 无穷级数

先引入 $0\le r<1$，对复数幂级数求和，再取虚部和左极限。

```mathematica
Clear[n, r, z];
series = Sum[(-1)^(n + 1) z^n/n, {n, 1, Infinity},
  Assumptions -> Abs[z] < 1];
AbelSum = Assuming[0 <= r < 1,
  FullSimplify[ComplexExpand[Im[series /. z -> r Exp[I]]]]];
Limit[AbelSum, r -> 1, Direction -> "FromBelow"]
```

复数级数的和为 $\log(1+z)$。原级数中 $(-1)^{n+1}\sin n$ 的部分和有界（它是公比为 $-e^{i}$ 的几何和的虚部），且 $1/n$ 单调趋于零，因此由狄利克雷判别法收敛。由阿贝尔定理，其和为

$$
\operatorname{Im}\log(1+e^{i})
=\operatorname{Im}\log\bigl(2\cos(1/2)e^{i/2}\bigr)
=\boxed{\tfrac{1}{2}}.
$$

## ii. 不定积分

在 $\tan x>0$ 的每个实数区间上令 $t=\sqrt{\tan x}$。因为 $\sec^2 x=1+t^4$，有 $\sqrt{\tan x}\,dx=2t^2/(1+t^4)\,dt$。

```mathematica
Clear[x, t];
primitive = Integrate[2 t^2/(1 + t^4), t, Assumptions -> t > 0];
primitive /. t -> Sqrt[Tan[x]]
```

整理得到

$$
\int\sqrt{\tan x}\,dx
=\frac{1}{2\sqrt{2}}\log\frac{t^2-\sqrt{2}t+1}{t^2+\sqrt{2}t+1}
+\frac{\arctan(\sqrt{2}t-1)+\arctan(\sqrt{2}t+1)}{\sqrt{2}}+C.
$$

<div class="page-break"></div>

# Navier–Stokes Equations

The Navier–Stokes momentum equation can be derived as a particular form of the Cauchy momentum equation, whose general convective form is:

$$
\frac{\mathrm{D}\mathbf{u}}{\mathrm{D}t}
=\frac{1}{\rho}\nabla\cdot\boldsymbol{\sigma}+\mathbf{a}.
$$

By setting the Cauchy stress tensor $\boldsymbol{\sigma}$ to be the sum of a viscosity term $\boldsymbol{\tau}$ (the deviatoric stress) and a pressure term $-p\mathbf{I}$ (volumetric stress), we arrive at:

$$
\rho\frac{\mathrm{D}\mathbf{u}}{\mathrm{D}t}
=-\nabla p+\nabla\cdot\boldsymbol{\tau}+\rho\,\mathbf{a}
$$

where

- $\frac{\mathrm{D}}{\mathrm{D}t}$ is the material derivative, defined as $\frac{\partial}{\partial t}+\mathbf{u}\cdot\nabla$,
- $\rho$ is the (mass) density,
- $\mathbf{u}$ is the flow velocity,
- $\nabla\cdot$ is the divergence,
- $p$ is the pressure,
- $t$ is time,
- $\boldsymbol{\tau}$ is the Deviatoric stress|deviatoric stress tensor, which has order 2,
- $\mathbf{a}$ represents body forces acting on the continuum, for example gravity, Fictitious force|inertial accelerations, Coulomb's law|electrostatic accelerations, and so on.

In this form, it is apparent that in the assumption of an inviscid fluid – no deviatoric stress – Cauchy equations reduce to the [Euler equations](https://en.wikipedia.org/wiki/Euler_equations_(fluid_dynamics)).
