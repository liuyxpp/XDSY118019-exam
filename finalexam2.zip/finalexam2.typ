#set page(paper: "a4", margin: (x: 2.1cm, y: 1.9cm), numbering: "1")
#set text(font: ("Times New Roman", "SimSun"), size: 10pt, lang: "zh", region: "cn")
#set par(justify: true, leading: 0.75em, spacing: 0.9em)
#show heading: set text(font: ("Microsoft YaHei", "SimHei"), weight: "bold")
#show heading.where(level: 1): set text(size: 14pt)
#show heading.where(level: 2): set text(size: 11.5pt)
#show raw: set text(font: ("Consolas", "Courier New", "SimSun"), size: 7.6pt)
#show link: it => underline(text(fill: rgb("#0b57d0"), it))

#align(center)[#text(size: 10.5pt)[学号：26803040166　　姓名：方月桐]]

= 第 1 题（30 分）

== minkowski.py（(i) 参数校验 + (ii) Examples）

```python
import math
import numpy as np
from scipy.linalg import norm

def _validate_vector(u, dtype=None):
    u = np.asarray(u, dtype=dtype, order='c')
    if u.ndim == 1:
        return u
    raise ValueError("Input vector should be 1-D.")


def _validate_weights(w, dtype=np.float64):
    w = _validate_vector(w, dtype=dtype)
    if np.any(w < 0):
        raise ValueError("Input weights should be all non-negative")
    return w


def _validate_p(p):
    """校验 Minkowski 距离的阶数 p：必须是大于 0 的实数，允许 p = inf。

    Parameters
    ----------
    p : scalar
        待校验的阶数。

    Returns
    -------
    p : float
        校验通过后的 p（统一转换为 Python float）。

    Raises
    ------
    TypeError
        p 不是实数（例如字符串、复数或布尔值）。
    ValueError
        p 为 NaN，或者 p <= 0。
    """
    if isinstance(p, (bool, np.bool_)):
        raise TypeError("p must be a real number, not bool.")
    if not isinstance(p, (int, float, np.integer, np.floating)):
        raise TypeError(f"p must be a real number, got {type(p).__name__}.")
    p = float(p)
    if math.isnan(p):
        raise ValueError("p must not be NaN.")
    if p <= 0:
        raise ValueError("p must be greater than 0.")
    return p


def minkowski(u, v, p=2, w=None):
    """
    Compute the Minkowski distance between two 1-D arrays.

    The Minkowski distance between 1-D arrays `u` and `v`,
    is defined as

    .. math::

       {\\|u-v\\|}_p = (\\sum{|u_i - v_i|^p})^{1/p}.


       \\left(\\sum{w_i(|(u_i - v_i)|^p)}\\right)^{1/p}.

    Parameters
    ----------
    u : (N,) array_like
        Input array.
    v : (N,) array_like
        Input array.
    p : scalar
        The order of the norm of the difference :math:`{\\|u-v\\|}_p`. Note
        that for :math:`0 < p < 1`, the triangle inequality only holds with
        an additional multiplicative factor, i.e. it is only a quasi-metric.
    w : (N,) array_like, optional
        The weights for each value in `u` and `v`. Default is None,
        which gives each value a weight of 1.0

    Returns
    -------
    minkowski : double
        The Minkowski distance between vectors `u` and `v`.

    Raises
    ------
    ValueError
        若 `u` 或 `v` 不是一维数组、两者长度不同、`w` 不是一维数组、含有负元素
        或长度与 `u` 不同，以及 `p` 不是正数时抛出。
    TypeError
        若 `p` 不是实数时抛出。

    Examples
    --------
    >>> from minkowski import minkowski
    >>> import numpy as np
    >>> minkowski([1, 0, 0], [0, 1, 0], 1)
    2.0
    >>> minkowski([1, 0, 0], [0, 1, 0], 2)
    1.4142135623730951
    >>> minkowski([1, 0, 0], [0, 1, 0], 3)
    1.2599210498948732
    >>> minkowski([1, 0, 0], [0, 1, 0], np.inf)
    1.0
    >>> minkowski([1, 2, 3], [3, 2, 1], 2, w=[0.1, 0.7, 0.2])
    1.0954451150103321
    >>> minkowski([1, 0, 0], [1, 0, 0])
    0.0
    >>> minkowski([0, 1, 1, 0], [1, 0, 0, 1], 0.5)
    16.0
    >>> minkowski([1, 0], [0, 1], 0)
    Traceback (most recent call last):
        ...
    ValueError: p must be greater than 0.
    >>> minkowski([1, 0], [0, 1], 2, w=[1.0, -1.0])
    Traceback (most recent call last):
        ...
    ValueError: Input weights should be all non-negative
    """
    u = _validate_vector(u)
    v = _validate_vector(v)
    p = _validate_p(p)
    if u.shape != v.shape:
        raise ValueError(
            "Input vectors must have the same length, got %d and %d."
            % (u.size, v.size))

    u_v = u - v
    if w is not None:
        w = _validate_weights(w)
        if w.shape != u.shape:
            raise ValueError(
                "Input weights must have the same length as the vectors, "
                "got %d and %d." % (w.size, u.size))
        if p == 1:
            root_w = w
        elif p == 2:
            # better precision and speed
            root_w = np.sqrt(w)
        elif p == np.inf:
            root_w = (w != 0)
        else:
            root_w = np.power(w, 1/p)
        u_v = root_w * u_v
    dist = norm(u_v, ord=p)
    return float(dist)


if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=False)
```

== (iii) 三对向量的 Minkowski 距离

#table(
  columns: 2,
  align: center,
  stroke: 0.5pt,
  [序号], [结果],
  [(1)], [$1.0954451150103321$],
  [(2)], [$36.0$],
  [(3)], [$1.9366833186578014$],
)

```python
"""第 1 题 (iii)：利用 minkowski 函数计算三对向量之间的 Minkowski 距离。

用法：
    python problem1_iii.py
"""

from minkowski import minkowski

CASES = [
    ("(1)", (1, 2, 3), (3, 2, 1), 2, (0.1, 0.7, 0.2)),
    ("(2)", (0, 1, 1, 0, 0, 1), (1, 0, 0, 1, 1, 0), 0.5, None),
    ("(3)", (0.1, 0.5, -0.3, -1.2), (-0.5, 1.5, 0.3, 0.6), 3, None),
]


def main():
    print("第 1 题 (iii)：三对向量的 Minkowski 距离")
    print("=" * 68)
    for tag, u, v, p, w in CASES:
        d = minkowski(u, v, p, w)
        print(f"{tag} u = {u}, v = {v}, p = {p}, w = {w}")
        print(f"    minkowski(u, v, p, w) = {d!r}")
        print()


if __name__ == "__main__":
    main()
```

#pagebreak()

= 第 2 题（20 分）

```matlab
% 第 2 题：用 surf 绘制克莱因瓶（Klein bottle）
%
% 用法：把本文件保存为 klein_bottle.m，在 MATLAB 中直接运行（或按 F5）。
%       运行后在“当前文件夹”生成 klein_bottle.png。
%
% 参数方程（u, v 均在 [0, 2*pi] 上取值）：
%   x(u,v) = -2/15*cos(u)*(3*cos(v) - 30*sin(u) + 90*cos(u)^4*sin(u)
%                          - 60*cos(u)^6*sin(u) + 5*cos(u)*cos(v)*sin(u))
%   y(u,v) = -1/15*sin(u)*(3*cos(v) - 3*cos(u)^2*cos(v) - 48*cos(u)^4*cos(v)
%                          + 48*cos(u)^6*cos(v) - 60*sin(u)
%                          + 5*cos(u)*cos(v)*sin(u) - 5*cos(u)^3*cos(v)*sin(u)
%                          - 80*cos(u)^5*cos(v)*sin(u) + 80*cos(u)^7*cos(v)*sin(u))
%   z(u,v) = 2/15*(3 + 5*cos(u)*sin(u))*sin(v)

clear; clc; close all;

n = 400;                                  % 每个方向的网格点数，越大越光滑
u = linspace(0, 2*pi, n);
v = linspace(0, 2*pi, n);
[U, V] = meshgrid(u, v);                  % 生成参数网格矩阵

cu = cos(U);  su = sin(U);
cv = cos(V);  sv = sin(V);

% 按题目给出的参数方程逐项写，注意所有乘、除、幂都要用点运算
X = -2/15 * cu .* (3*cv - 30*su + 90*cu.^4 .*su - 60*cu.^6 .*su ...
                   + 5*cu .*cv .*su);

Y = -1/15 * su .* (3*cv - 3*cu.^2 .*cv - 48*cu.^4 .*cv + 48*cu.^6 .*cv ...
                   - 60*su + 5*cu .*cv .*su - 5*cu.^3 .*cv .*su ...
                   - 80*cu.^5 .*cv .*su + 80*cu.^7 .*cv .*su);

Z = 2/15 * (3 + 5*cu .*su) .* sv;

% ---- 用 surf 绘制三维曲面 ----
figure('Color', 'w', 'Position', [100 100 800 640]);
h = surf(X, Y, Z, 'EdgeColor', 'none');   % EdgeColor none：去掉网格线更光滑
set(h, 'FaceColor', 'interp');            % 面颜色随 z 值插值
colormap(jet(256));                       % MATLAB 经典的 jet 配色
shading interp;                           % 插值着色
material dull;                            % 光照更柔和
camlight('headlight');                    % 加一盏随相机移动的光源
lighting gouraud;                         % Gouraud 光照

axis equal;                               % 三个坐标轴等比例，形状不变形
axis tight;
grid on; box on;
xlabel('x'); ylabel('y'); zlabel('z');
title('Klein bottle:  x(u,v), y(u,v), z(u,v),  u,v \in [0, 2\pi]');
view(-70, 28);                            % 视角：方位角 -70°，仰角 28°

% ---- 自检：打印坐标范围，应与预期一致 ----
fprintf('x: [%.3f, %.3f]\n', min(X(:)), max(X(:)));
fprintf('y: [%.3f, %.3f]\n', min(Y(:)), max(Y(:)));
fprintf('z: [%.3f, %.3f]\n', min(Z(:)), max(Z(:)));

% ---- 保存图片（新旧版本 MATLAB 都可用）----
try
    exportgraphics(gcf, 'klein_bottle.png', 'Resolution', 300);   % R2020a 及以上
catch
    print(gcf, '-dpng', '-r300', 'klein_bottle.png');
end
disp('已保存 klein_bottle.png');
```

#figure(
  image("klein_bottle.png", width: 80%),
  caption: [克莱因瓶，$u, v in [0, 2pi]$],
)

= 第 3 题（20 分）

== (i) 无穷级数

```mathematica
In[1]:= Sum[(-1)^(n + 1) Sin[n]/n, {n, 1, Infinity}]
Out[1]= 1/2
```

== (ii) 不定积分

```mathematica
In[2]:= Integrate[Sqrt[Tan[x]], x]
```

$ integral sqrt(tan x) dif x = 1/(2 sqrt(2)) ln (1 - sqrt(2) t + t^2)/(1 + sqrt(2) t + t^2) + 1/sqrt(2) [arctan(sqrt(2) t - 1) + arctan(sqrt(2) t + 1)] + C, quad t = sqrt(tan x) $

== MATLAB 复核

```text
symsum 结果       : (log(exp(-1i) + 1)*1i)/2 - (log(exp(1i) + 1)*1i)/2
数值              : 0.500000000000000
前 1000000 项部分和: 0.4999999191216342
int 结果          : (2^(1/2)*(log(2^(1/2)*tan(x)^(1/2) - tan(x) - 1) - log(tan(x) + 2^(1/2)*tan(x)^(1/2) + 1)))/4 + (2^(1/2)*(atan(2^(1/2)*tan(x)^(1/2) - 1) + atan(2^(1/2)*tan(x)^(1/2) + 1)))/2
diff(F)-sqrt(tan x) 化简 = 0
定积分 (符号)     : (2^(1/2)*(atan(2^(1/2)*tan(1)^(1/2) - 1) + atan(2^(1/2)*tan(1)^(1/2) + 1)))/2 - (2^(1/2)*(log(tan(1) + 2^(1/2)*tan(1)^(1/2) + 1) - log(tan(1) - 2^(1/2)*tan(1)^(1/2) + 1)))/4
定积分 (符号) 数值: 0.727298249343511
定积分 (数值)     : 0.727298249343511
[0,pi/2] 符号结果 : (2^(1/2)*pi)/2
```

#pagebreak()

= 第 4 题（30 分）

#block(width: 100%)[
  #set text(font: ("Times New Roman", "SimSun"), size: 10.5pt)
  #set par(justify: true, leading: 0.85em)

  #block(above: 0em, below: 0.9em)[
    #text(font: ("Arial"), weight: "bold", size: 21pt)[Navier--Stokes Equations]
  ]

  The Navier–Stokes momentum equation can be derived as a particular form of the Cauchy
  momentum equation, whose general convective form is:

  #align(center)[
    $ (dif bold(u))/(dif t) = 1/rho nabla dot sigma + bold(a). $
  ]

  By setting the Cauchy stress tensor $sigma$ to be the sum of a viscosity term $tau$ (the deviatoric stress) and
  a pressure term $-p bold(I)$ (volumetric stress), we arrive at:

  #align(center)[
    $ rho (dif bold(u))/(dif t) = -nabla p + nabla dot tau + rho bold(a) $
  ]

  where

  #set list(indent: 1.2em, body-indent: 0.5em)
  - $(dif bold(u))/(dif t)$ is the material derivative, defined as $partial/(partial t) + bold(u) dot nabla$,
  - $rho$ is the (mass) density,
  - $bold(u)$ is the flow velocity,
  - $nabla dot$ is the divergence,
  - $p$ is the pressure,
  - $t$ is time,
  - $tau$ is the Deviatoric stress|deviatoric stress tensor, which has order 2,
  - $bold(a)$ represents body forces acting on the continuum, for example gravity, Fictitious force|inertial accelerations, Coulomb's law|electrostatic accelerations, and so on.

  #v(0.4em)

  In this form, it is apparent that in the assumption of an inviscid fluid – no deviatoric stress – Cauchy
  equations reduce to the #link("https://en.wikipedia.org/wiki/Euler_equations_(fluid_dynamics)")[Euler equations].
]
